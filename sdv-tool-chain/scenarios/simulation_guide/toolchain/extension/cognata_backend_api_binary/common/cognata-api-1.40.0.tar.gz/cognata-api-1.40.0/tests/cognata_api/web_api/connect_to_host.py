import json
import socket
from retry_decorator import retry

from cognata_api.web_api.cognata_api_wrapper import CognataRequests

# Sporadically, gethostbyname raises a 'gaierror' Exception.
# Retry if the occurs
@retry(socket.gaierror, tries=3)
def connect_to_server(connection_config=None):
    if connection_config is None:
        connection_config = "connection_config/config.json"

    creds = json.load(open(connection_config))
    local = creds.get("local")
    if local:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        backend_url = f"http://{local_ip}:8100/v1"
        print(f"\n=====> CONNECTING TO LOCAL HOST <=====")
    else:
        backend_url = creds['client_api_url']

    api = CognataRequests(backend_url, creds.get('user'), creds.get('password'))

    return api
