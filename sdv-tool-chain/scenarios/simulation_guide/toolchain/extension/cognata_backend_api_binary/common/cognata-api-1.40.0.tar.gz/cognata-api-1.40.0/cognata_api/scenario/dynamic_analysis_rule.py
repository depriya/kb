class DynamicAnalysisRule:
    def __init__(self, sku, rule_id, rule_defs: dict = None):
        """
        DAR constructor

        :param sku: string
        :type sku: the SKU of the dar as described in catalog
        :param rule_id: string
        :type rule_id: the ID string to add to the
        :param rule_defs: dict
        :type rule_defs: the definition of the arguments and their values to pass to the rule. each key in the dictionary
            should be the arg name as described in catalog and value would be the value to pass
        """
        self.sku = sku
        self.rule_id = rule_id
        self.rule_defs = rule_defs or {}

    def to_json(self):
        return {
            "sku": self.sku,
            "RuleID": self.rule_id,
            "RuleDefs": self.rule_defs
        }
