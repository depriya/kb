from enum import Enum

class DespawnMode(Enum):
    DONT_DESPAWN = 0
    DESPAWN = 1