import json
import jsonschema
import pytest
import random
from tests.cognata_api.web_api.connect_to_host import connect_to_server

# This compatibility test is mainly to check the response objects schemes
# had not changed. The values are less important for the sake of this test module.
#
# The strategy is to define a request body (for non-GET requests) -> Send request ->
# and test an expected response schema for every function call was returned.
#
# Note: The meaning here of response object, is not the 'raw' response from CognataStudio, but a
# return value of the SDK functions

@pytest.fixture(scope='module')
def cognata_api():
    return connect_to_server()


@pytest.fixture
def random_simulation(cognata_api):
    try:
        sim_list = cognata_api.get_simulations_list(limit=1).get('data')
        random_simulation = sim_list[random.randrange(len(sim_list))]
        print(f"Random simulation: {random_simulation.get('_id')}")
    except Exception as e:
        raise RuntimeError(f"[FIXTURE::random_simulation] Didn't get random simulation. Reason: {e}")
    return random_simulation

@pytest.fixture
def random_simulation_id(random_simulation):
    return random_simulation.get("_id")


@pytest.fixture
def random_run(cognata_api):
    try:
        run_list = cognata_api.find_simulation_runs_queue(status="completed", limit=1).get('data')
        random_run_from_queue = run_list[random.randrange(len(run_list))]
        random_run = cognata_api.find_simulation_run(random_run_from_queue.get('id'))
        print(f"Random simulation run: {random_run.get('_id')}")
    except Exception as e:
        raise RuntimeError(f"[FIXTURE::random_run] Didn't get random run. Reason: {e}")
    return random_run

@pytest.fixture
def random_run_id(random_run):
    return random_run.get("_id")


@pytest.fixture
def random_tpex(cognata_api):
    try:
        tpex_list = list(filter(    # filter() returns a generator, make list
            lambda t: t.get("progress") == 1,    # take completed tpex's only
            cognata_api.get_test_plan_execution_list()))
        random_tpex = tpex_list[random.randrange(len(tpex_list))]
        print(f"Random tpex: {random_tpex.get('_id')}")
        return random_tpex
    except Exception as e:
        raise RuntimeError(f"[FIXTURE::random_tpex] Didn't get random tpex. Reason: {e}")


@pytest.fixture
def random_tpex_id(random_tpex):
    return random_tpex.get("_id")


@pytest.fixture
def random_test_plan(cognata_api):
    try:
        tp_list = cognata_api.get_test_plans_list(lite=True)
        random_tp = tp_list[random.randrange(len(tp_list))]
        print(f"Random test plan: {random_tp.get('sku')}")
        return random_tp
    except Exception as e:
        raise RuntimeError(f"[FIXTURE::random_test_plan_sku] Didn't get random test plan. Reason: {e}")


@pytest.fixture
def random_test_plan_sku(random_test_plan):
    return random_test_plan.get("sku")


def load_scheme_and_body(scheme_path:str, body_path:str=None) -> tuple:
    """Load scheme and (if requested) body JSON files as dictionaries

    Body might not be desired in GET requests, but scheme is always expected to be needed
    """
    with open(scheme_path, 'r') as scheme_f:
        scheme = json.load(scheme_f)
    body = None # Initialize in case will not be read
    if body_path:
        with open(body_path, 'r') as body_f:
            body = json.load(body_f)

    return (scheme, body)


@pytest.mark.parametrize(
    'body',[
        'golden_standard/example_bodies/generate_single_simulation.json'
    ]
)
@pytest.mark.parametrize('running_priority', [10])
def test_generate_simulation_PASS(cognata_api, body, running_priority):
    expected_schema, scenario_data = load_scheme_and_body(
        'golden_standard/response_schemes/generate_single_simulation.json',
        body
    )

    resp = cognata_api.generate_simulation(
        scenario_data,
        client_driver_version='',
        cognata_engine_version='',
        annotate=False,
        visibility_report=False,
        driver_mode=None,
        running_priority=running_priority
    )

    jsonschema.validate(instance=resp, schema=expected_schema)


def test_get_simulation_run_status_PASS(cognata_api, random_run_id, random_run):
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/get_sim_status.json')

    resp = cognata_api.get_simulation_run_status(random_run_id)
    jsonschema.validate(instance=resp, schema=expected_schema)
    assert random_run.get('status') == resp


def test_get_simulation_run_queue_PASS(cognata_api, random_run_id, random_run):
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/get_simulation_run_queue.json')
    resp = cognata_api.get_simulation_run_queue(random_run_id)
    jsonschema.validate(instance=resp, schema=expected_schema)
    assert random_run.get('queue_id') == resp


def test_get_simulation_run_id_PASS(cognata_api):
    # Generate simulation, the response will be used as input for the tested function: get_simulation_run_id
    with open('golden_standard/example_bodies/generate_single_simulation.json', 'r') as sim_f:
        scenario_data = json.load(sim_f)
    generated = cognata_api.generate_simulation(scenario_data)

    # Function under test
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/get_simulation_run_id.json')
    resp = cognata_api.get_simulation_run_id(generated)
    jsonschema.validate(instance=resp, schema=expected_schema)

    # Compare data
    run_details = cognata_api.find_simulation_run(resp)
    assert run_details.get('simulation_id') == generated[0]


def test_get_simulation_run_files_list_PASS(cognata_api, random_run_id, random_run):
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/get_simulation_run_files_list.json')
    resp = cognata_api.get_simulation_run_files_list(random_run_id)
    jsonschema.validate(instance=resp, schema=expected_schema)

    # Compare data
    assert random_run.get('simulation_files') == resp


@pytest.mark.repeat(13)
def test_get_test_plan_execution_runs_PASS(cognata_api, random_tpex_id):
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/get_test_plan_execution_runs.json')

    resp = cognata_api.get_test_plan_execution_runs(random_tpex_id)
    # resp = cognata_api.get_test_plan_execution_runs("63c514f229f294002f94a70f")
    jsonschema.validate(instance=resp, schema=expected_schema)


def test_execute_test_plan(cognata_api, random_test_plan_sku):
    expected_schema, _ = load_scheme_and_body('golden_standard/response_schemes/execute_test_plan.json')
    # Execute test plan
    resp = cognata_api.execute_test_plan(
        test_plan_sku=random_test_plan_sku,
        ego_car_sku='AISUV',
        sensors_preset_sku='SINGLECA',
        car_physics_sku='SUVCARPHYSICS',
        running_priority=10
    )
    jsonschema.validate(instance=resp, schema=expected_schema)


def test_wait_for_simulation_to_finish(cognata_api, random_run_id, random_run):
    resp = cognata_api.wait_for_simulation_to_finish(random_run_id, wait_timeout=1)
    assert resp == random_run.get('status')


@pytest.mark.parametrize('status',
    ['pending', 'running', "analysis_pending", "analysis", "completed", "aborted", "", 0, None,
    # BAD STATUSES
    pytest.param(1, marks=pytest.mark.xfail(reason="Invalid input")),
    pytest.param("komplet", marks=pytest.mark.xfail(reason="Invalid input")),
    pytest.param("12", marks=pytest.mark.xfail(reason="Invalid input"))
    ]
)
def test_find_simulation_runs_queue(cognata_api, status):
    run_list = cognata_api.find_simulation_runs_queue(status=status).get('data')
    assert isinstance(run_list, list)
    # TODO: Validate scheme
    # TODO: Deeper test of data returned
