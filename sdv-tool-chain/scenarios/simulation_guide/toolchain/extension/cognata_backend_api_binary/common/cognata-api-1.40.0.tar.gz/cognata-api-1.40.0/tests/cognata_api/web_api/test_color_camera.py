from typing import List

import pytest
import time
import json
from tests.cognata_api.web_api.connect_to_host import connect_to_server
import cognata_api.web_api.cognata_api_wrapper as sdk


@pytest.fixture
def cognata_api():
    return connect_to_server()


def test_color_camera(cognata_api):
    preset = []

    gps = sdk.CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
                            sensor_record={"gps": True},
                            sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                            sensor_position={"x": 0, "z": 1.7, "y": 0})
    preset.append(gps.get_sensor_for_preset())

    basic_color_cam = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name="basic_color_cam",
                                        sensor_record={"color": True},
                                        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                        sensor_position={"x": 0, "y": 1.8, "z": 0},
                                        fullscreen={"color": False},
                                        output_format={"color": "JPG"},
                                        bit_depth={"color": "UINT8"},
                                        color_filter={"color": "RGB"})
    preset.append(basic_color_cam.get_sensor_for_preset())
    old_rgb_cam = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"old_rgb_cam",
                                    sensor_record={"rgb": True},
                                    sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                    sensor_position={"x": 0, "y": 1.8, "z": 0},
                                    quality={"rgb": "Standard"},
                                    fullscreen={"rgb": True})
    preset.append(old_rgb_cam.get_sensor_for_preset())


    print(json.dumps(preset, sort_keys=True, indent=4))
    preset_name = f"SDK-color_test_{time.time()}"
    res = cognata_api.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV", sensors=preset)
    print(json.dumps(res, indent=4))
    assert not (hasattr(res, "message") and hasattr(res, "stack"))

def test_invalid_color_props_input(cognata_api):
    preset = []

    gps = sdk.CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
                            sensor_record={"gps": True},
                            sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                            sensor_position={"x": 0, "z": 1.7, "y": 0})
    preset.append(gps.get_sensor_for_preset())

    invalid_props_input = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM",
                                            sensor_name="basic_color_cam",
                                            sensor_record={"color": True},
                                            sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                            sensor_position={"x": 0, "y": 1.8, "z": 0},
                                            fullscreen={"color": False},
                                            output_format={"color": "xxx"},
                                            bit_depth={"color": "UINT8"},
                                            color_filter={"color": "RGB"})
    preset.append(invalid_props_input.get_sensor_for_preset())
    wrong_color_props_comb = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM",
                                               sensor_name=f"wrong_props_comb",
                                               sensor_record={"color": True},
                                               sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                               sensor_position={"x": 0, "y": 1.8, "z": 0},
                                               fullscreen={"color": False},
                                               output_format={"color": "PNG"},
                                               bit_depth={"color": "UINT8"},
                                               color_filter={"color": "RCCG"})
    preset.append(wrong_color_props_comb.get_sensor_for_preset())

    print(json.dumps(preset, sort_keys=True, indent=4))
    preset_name = f"SDK-color_test_{time.time()}"
    res = cognata_api.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV", sensors=preset)
    print(json.dumps(res, indent=4))


