import json
import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server


@pytest.fixture
def cognata_api():
    return connect_to_server()


FBX_FILE = "test_data/fbx_file_for_testing.fbx"
ASSET_FILES = ["test_data/dynamic_object_asset.json", "test_data/moving_object_asset.json"]
INVALID_PHYSICS = ["GARBAGE", "", None]
VALID_PHYSICS = "SUVCARPHYSICS"

XFAIL_PARAMS = [
    (pytest.param(FBX_FILE, asset_file, bool_val, physics, marks=pytest.mark.xfail))
    for asset_file in ASSET_FILES
    for physics in INVALID_PHYSICS
    for bool_val in [True, False]
    if not ('moving' in asset_file and not bool_val and physics is None or physics == "")
]

VALID_PARAMS = [
    (FBX_FILE, "test_data/moving_object_asset.json", False, None),
    (FBX_FILE, "test_data/moving_object_asset.json", False, ""),
    (FBX_FILE, "test_data/dynamic_object_asset.json", True, "SUVCARPHYSICS"),
    (FBX_FILE, "test_data/dynamic_object_asset.json", False, "SUVCARPHYSICS"),
]

PARAMS = [
    *XFAIL_PARAMS,
    *VALID_PARAMS
]


@pytest.mark.parametrize("fbx_file, asset_json, make_ego, physics", PARAMS)
def test_import_asset(cognata_api, asset_json, fbx_file, make_ego, physics):
    tp_body = cognata_api.create_catalog_asset(
        fbx_file=fbx_file,
        asset_json=asset_json,
        make_ego_car=make_ego,
        default_car_physics_sku=physics
    )
    print(json.dumps(tp_body, indent=2))
