# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from os import path, makedirs
import json

from cognata_api.web_api.cognata_api_wrapper import CognataRequests


def get_simulation_config(api, sim_id, path_to_save):
    res_path = api.download_simulation_engine_config(sim_id, path_to_save)
    return res_path


def download_simulation_parent_configs(api, parent_id, path_to_save):
    index_dict = {
        "parent_simulation": parent_id,
        "simulations": []
    }
    res = api.find_simulation_parent(parent_id)
    if not res:
        print("Failed to find simulation parent of id {}".format(parent_id))
        return False

    simulations_list = res["simulations"]
    print("Simulation parent {} has {} single simulations".format(parent_id, len(simulations_list)))
    for sim_id in simulations_list:
        engine_config_path = get_simulation_config(api, sim_id, path_to_save)
        index_dict["simulations"].append({"sim_id": sim_id, "config_path": engine_config_path})

    with open(path.join(path_to_save, "index.json"), 'a') as index_file:
        index_file.write(json.dumps(index_dict, indent=2))
    return True


def generate_scenario_simulations(api, scenario_id, driver_version):
    res = api.find_scenario(scenario_id)
    res = api.generate_simulation(res, client_driver_version=driver_version)
    if "error" in res:
        print("Generate simulations failed: Message: {}".format(res["message"]))
        return

    cnt = len(res)
    print("generated {} simulations:".format(cnt))
    return res[0]["simulation_parent"]


def generate_scenario_and_download_configs_with_premade_api(api, scenario_id, path_to_save, driver_version=""):
    parent_id = generate_scenario_simulations(api, scenario_id, driver_version)
    if not parent_id:
        return
    return download_simulation_parent_configs(api, parent_id, path_to_save)


def generate_scenario_and_download_configs_with_credentials(api_url, user, password, scenario_id, path_to_save, driver_version=""):
    api = CognataRequests(api_url, user, password)
    return generate_scenario_and_download_configs_with_premade_api(api, scenario_id, path_to_save, driver_version)


if __name__ == "__main__":
    small_scenario_local = "5c7f9a5ddb7326116b4880ee"
    big_scenario_local   = "5c7f9b1ddb7326116b4880fd"
    big_scenario_remote  = "5c7fb2b619a204002641b66c"
    # scenario_id = small_scenario
    # scenario_id = big_scenario_local
    scenario_id = big_scenario_remote

    remote_url = "http://52.174.38.40:8100/v1"
    local_url = "http://localhost:8100/v1"
    api_url = remote_url

    api = CognataRequests(api_url, "admin2018", "Cognata2018")
    path_to_save = path.expanduser(path.join("~", "Desktop", "scenario2_big_2"))
    if not path.exists(path_to_save):
        makedirs(path_to_save)
    generate_scenario_and_download_configs_with_premade_api(api, scenario_id, path_to_save)
    # Use the following for re-downloading a scenario you already generated
    # download_simulation_parent_configs(api, "5c7fb34d19a204002641b66e", path_to_save)
