import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server
from cognata_api.web_api.cognata_demo import CognataRequests

INVALID_DRIVER_MODELS = [(
    {
        "catalogData": {
            "name": "New standard driver",
            "description": "Standard Cognata driver",
            "read_only": True,
            "type": "driverModel"
        },
        "properties": {
        }
    }, '\\"catalogData.brandID\\" is required'), (
    {
        "catalogData": {
            "brandID": "STANDARD",
            "description": "Standard Cognata driver",
            "read_only": True,
            "type": "driverModel"
        },
        "properties": {
        }
    }, '\\"catalogData.name\\" is required')]

@pytest.fixture
def cognata_api():
    return connect_to_server()

def test_driver_model_create(cognata_api: CognataRequests):
    driver_model_req_payload = {
        "catalogData": {
            "name": "New standard driver",
            "description": "Standard Cognata driver",
            "read_only": True,
            "type": "driverModel",
            "brandID": "STANDARD"
        },
        "properties": {
        }
    }
    response = cognata_api.create_driving_model(driver_model_req_payload)
    response.raise_for_status()

    driver_model = response.json()
    assert driver_model["sku"] is not None
    assert driver_model["name"] == driver_model_req_payload["catalogData"]["name"]
    assert driver_model["description"] == driver_model_req_payload["catalogData"]["description"]
    assert driver_model["type"] == driver_model_req_payload["catalogData"]["type"]
    assert driver_model["read_only"] == driver_model_req_payload["catalogData"]["read_only"]
    assert driver_model["brandID"] == driver_model_req_payload["catalogData"]["brandID"]

@pytest.mark.parametrize("driver_model_req_payload, expected_error_message", INVALID_DRIVER_MODELS)
def test_driver_model_create_fails(cognata_api: CognataRequests, driver_model_req_payload, expected_error_message: str):
    try:
        cognata_api.create_driving_model(driver_model_req_payload)
    except RuntimeError as error:
        error_message = str(error).replace("\n", "")
        assert expected_error_message in error_message


def test_driver_model_list(cognata_api: CognataRequests):
    driver_models = cognata_api.get_driving_models()
    for dm in driver_models:
        assert dm["sku"] is not None
        assert dm["name"] is not None
        assert dm["description"] is not None
        assert dm["type"] is not None
        assert dm["read_only"] is not None
        assert dm["brandID"] is not None

def test_driver_model_delete(cognata_api: CognataRequests):
    response = cognata_api.delete_driving_model("NEWSTAND")
    response.raise_for_status()