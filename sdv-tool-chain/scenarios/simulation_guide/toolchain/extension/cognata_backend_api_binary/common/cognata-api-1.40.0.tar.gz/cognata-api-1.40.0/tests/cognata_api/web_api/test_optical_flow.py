from typing import List

import pytest
import time

from tests.cognata_api.web_api.sensors_utils import get_camera, get_gps
from tests.cognata_api.web_api.connect_to_host import connect_to_server

api = connect_to_server()


@pytest.fixture
def cognata_api():
    return connect_to_server()


OPTICAL_FLOW_PARAMS = [
    (None, None),
    (True, None),
    (False, None),
    (True, 3),
    (False, -12),  # Negatives are not allowed. default value speed factor will be assigned
    pytest.param(True, "abc", marks=pytest.mark.xfail),  # Invalid input rejection
]


@pytest.mark.parametrize("record_optical_flow, optical_flow_speed_factor", OPTICAL_FLOW_PARAMS)
def test_optical_flow_cam(cognata_api, record_optical_flow, optical_flow_speed_factor):
    preset = []
    gps = get_gps()
    cam = get_camera(of=record_optical_flow, of_speed_factor=optical_flow_speed_factor)
    preset.append(gps)
    preset.append(cam)
    # Create base sensors preset
    preset_name = f"optical_flow_{time.time()}"
    res = cognata_api.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV", sensors=preset)
    assert res["sku"] is not None