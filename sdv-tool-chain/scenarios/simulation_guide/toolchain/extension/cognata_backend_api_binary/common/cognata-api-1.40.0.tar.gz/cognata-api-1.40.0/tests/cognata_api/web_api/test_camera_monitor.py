import json
import os
import time

import cognata_api
import cognata_api.web_api.cognata_api_wrapper as sdk

if __name__ == "__main__":
    config_path = os.environ.get("STUDIO_SDK_CONFIG", None)
    if not config_path:
        print("No config!")
        exit(1)
    with open(config_path, 'r') as config:
        client = sdk.CognataRequests(**json.load(config))

    preset = []

    gps = sdk.CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
        sensor_record={"gps": True}, sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
        sensor_position={"x": 0, "z": 1.7, "y": 0})
    preset.append(gps.get_sensor_for_preset())

    camera_base = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"FS_FALSE_MONITOR_DEFAULT", sensor_record={"rgb":True},
        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
        sensor_position={"x":0, "y": 1.8, "z": 0},
        quality={"rgb": 0},
        fullscreen={"rgb": False})
    preset.append(camera_base.get_sensor_for_preset())
    camera_base = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"FS_TRUE_MONITOR_DEFAULT", sensor_record={"rgb":True},
        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
        sensor_position={"x":0, "y": 1.8, "z": 0},
        quality={"rgb": 0},
        fullscreen={"rgb": True})
    preset.append(camera_base.get_sensor_for_preset())
    camera_base = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"FS_DEFAULT_MONITOR_0", sensor_record={"rgb":True},
        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
        sensor_position={"x":0, "y": 1.8, "z": 0},
        quality={"rgb": 0},
        display_monitor={"rgb": 0})
    preset.append(camera_base.get_sensor_for_preset())
    camera_base = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"FS_DEFAULT_MONITOR_1", sensor_record={"rgb":True},
        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
        sensor_position={"x":0, "y": 1.8, "z": 0},
        quality={"rgb": 0},
        display_monitor={"rgb": 1})
    preset.append(camera_base.get_sensor_for_preset())
    camera_base = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name=f"FS_TRUE_MONITOR_1", sensor_record={"rgb":True},
        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
        sensor_position={"x":0, "y": 1.8, "z": 0},
        quality={"rgb": 0},
        fullscreen={"rgb": True},
        display_monitor={"rgb": 1})
    preset.append(camera_base.get_sensor_for_preset())
    print(json.dumps(preset))
    preset_name = f"SDK-{time.time()}"
    res = client.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV",
        sensors=preset)
    print(res)