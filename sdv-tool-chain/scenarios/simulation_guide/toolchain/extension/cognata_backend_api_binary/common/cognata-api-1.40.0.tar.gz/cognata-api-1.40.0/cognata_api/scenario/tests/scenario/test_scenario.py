# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import unittest
import json

from cognata_api.scenario.rule_gen.scenario2 import gen_scenario2

from cognata_api.web_api.cognata_api_wrapper import CognataRequests
from cognata_api.scenario.terrain import Terrain
from cognata_api.scenario.scenario import Scenario
from cognata_api.scenario import actor_script as ActorScript
from cognata_api.scenario import ai_vehicle as AIVehicle
from cognata_api.scenario import position as Position
from cognata_api.scenario.variable import Variable
from cognata_api.utils.utils import color_to_hex, range_object


class ScenarioTests(unittest.TestCase):
    def __init__(self, b):
        super(ScenarioTests, self).__init__(b)
        self.maxDiff = None

    def setUp(self):
        AIVehicle.STATIC_SPAWN_OBJECTS_CNT = 1
        AIVehicle.STATIC_DYNAMIC_OBJECTS_CNT = 1
        AIVehicle.STATIC_MOVING_OBJECTS_CNT = 1

    def test_scenario_variables_identification_WORKS(self):
        expected = {
            "analysis_rules": [
                {
                    "Sku": "Target1_002.04.01",
                    "RuleDefs": {
                        "ToleranceType": "abs",
                        "RuleType": "Verification",
                        "Target": "EgoCar",
                        "ReferenceSpeed": 0,
                        "Tolerance": 0.56
                    },
                    "LogFormat": " Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "ON_0"
                            },
                            {
                                "ToleranceType": "percentage",
                                "Tolerance": 0.05,
                                "TriggerValue": 0,
                                "type": "distance",
                                "id": "ON_1"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": 1,
                                "type": "TriggerFramesFromTriggerOn",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MaintainSpeedRule",
                    "id": "analysis_rules_0"
                },
                {
                    "Sku": "Target1_002.05.01",
                    "RuleDefs": {
                        "ToleranceType": "percentage",
                        "RuleType": "Verification",
                        "Target": "EgoCar",
                        "Tolerance": 0.05,
                        "ReferenceDistance": 0
                    },
                    "LogFormat": " Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "ON_0"
                            },
                            {
                                "TriggerValue": 0.08,
                                "type": "TriggerAccelerationLocalMinima",
                                "id": "ON_1"
                            },
                            {
                                "ToleranceType": "abs",
                                "Target": "InterVehicle",
                                "type": "TriggerSpeed",
                                "TriggerValue": 0,
                                "Tolerance": 0.56,
                                "id": "ON_2"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": 15,
                                "type": "TriggerTimeFromTriggerOn",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MaintainDistanceRule",
                    "id": "analysis_rules_1"
                },
                {
                    "Sku": "Target1_002.R.1",
                    "RuleDefs": {
                        "AnchorName": "Road Start",
                        "RuleType": "RunningConditon",
                        "BelongingLane": 0,
                        "Target": "EgoCar",
                    },
                    "LogFormat": " Ego is not in belonging lane ",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 0,
                                "type": "TriggerTimeFromSimStart",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "EndOfSimulation",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "VerifyLaneIDRule",
                    "id": "analysis_rules_2"
                },
                {
                    "Sku": "Target1_002.R.2",
                    "RuleDefs": {
                        "AnchorName": "Road Start",
                        "RuleType": "RunningConditon",
                        "BelongingLane": 0,
                        "Target": "AiCar",
                    },
                    "LogFormat": " Ego is not in belonging lane ",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 0,
                                "type": "TriggerTimeFromSimStart",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "EndOfSimulation",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "VerifyLaneIDRule",
                    "id": "analysis_rules_3"
                },
                {
                    "Sku": "Target1_002.R.3",
                    "RuleDefs": {
                        "ToleranceType": "abs",
                        "RuleType": "RunningConditon",
                        "Target": "EgoCar",
                        "WarnTolerance": 0.2,
                        "Tolerance": 0.2
                    },
                    "LogFormat": " Lateral Displacement {EgoLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 1,
                                "type": "TriggerTimeFromSimStart",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "DisplacementFromLaneCenterRule",
                    "id": "analysis_rules_4"
                },
                {
                    "Sku": "Target1_002.R.4",
                    "RuleDefs": {
                        "ToleranceType": "abs",
                        "RuleType": "RunningConditon",
                        "Target": "AiCar",
                        "WarnTolerance": 0.2,
                        "Tolerance": 0.2
                    },
                    "LogFormat": " Lateral Displacement {AiCarLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 1,
                                "type": "TriggerTimeFromSimStart",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "EndOfSimulation",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "DisplacementFromLaneCenterRule",
                    "id": "analysis_rules_5"
                },
                {
                    "Sku": "Target1_002.R.5",
                    "RuleDefs": {
                        "ToleranceType": "percentage",
                        "RuleType": "RunningConditon",
                        "Target": "EgoCar",
                        "Tolerance": 0.1,
                        "ReferenceDistance": 0
                    },
                    "LogFormat": " Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 1,
                                "type": "FramesBeforeTriggerOff",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MaintainDistanceRule",
                    "id": "analysis_rules_6"
                },
                {
                    "Sku": "Target1_002.R.6",
                    "RuleDefs": {
                        "ToleranceType": "abs",
                        "RuleType": "RunningConditon",
                        "Target": "EgoCar",
                        "ReferenceSpeed": 0,
                        "Tolerance": 0.56
                    },
                    "LogFormat": " Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 1,
                                "type": "FramesBeforeTriggerOff",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MaintainSpeedRule",
                    "id": "analysis_rules_7"
                },
                {
                    "Sku": "Target1_002.R.7",
                    "RuleDefs": {
                        "ToleranceType": "abs",
                        "RuleType": "RunningConditon",
                        "Target": "AiCar",
                        "ReferenceSpeed": 0,
                        "Tolerance": 0.56
                    },
                    "LogFormat": " Ego speed {AiCarSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": "AD-ON",
                                "type": "event",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "EndOfSimulation",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MaintainSpeedRule",
                    "id": "analysis_rules_8"
                },
                {
                    "Sku": "Target1_002.R.8",
                    "RuleDefs": {
                        "Message": "ADStart",
                        "RuleType": "RunningConditon",
                        "Target": "EgoCar",
                    },
                    "LogFormat": " message appears {MessageCount} times",
                    "Trigger": {
                        "ON": [
                            {
                                "TriggerValue": 0,
                                "type": "TriggerTimeFromSimStart",
                                "id": "ON_0"
                            }
                        ],
                        "OFF": [
                            {
                                "TriggerValue": "EndOfSimulation",
                                "type": "event",
                                "id": "OFF_0"
                            }
                        ]
                    },
                    "RuleName": "MessagesCountRule",
                    "id": "analysis_rules_9"
                }
            ],
            "variables": [
                {
                    "name": "myVar",
                    "fields": [
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_0.RuleDefs.ReferenceSpeed",
                            "offset": -2.78
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_0.Trigger.ON.id__ON_1.TriggerValue",
                            "offset": 0.0
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_1.RuleDefs.ReferenceDistance",
                            "offset": 0.0
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_2.RuleDefs.BelongingLane",
                            "offset": 0.0
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_3.RuleDefs.BelongingLane",
                            "offset": 0.0
                        },
                        {
                            "factor": 0.5,
                            "field_path": "analysis_rules.id__analysis_rules_6.RuleDefs.ReferenceDistance",
                            "offset": 0.0
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_7.RuleDefs.ReferenceSpeed",
                            "offset": -2.78
                        },
                        {
                            "factor": 1.0,
                            "field_path": "analysis_rules.id__analysis_rules_8.RuleDefs.ReferenceSpeed",
                            "offset": -2.78
                        },
                        {
                            "factor": 34.0,
                            "field_path": "ego_car.initial_speed",
                            "offset": 12.0
                        }
                    ],
                    "data_type": "integer",
                    "variable_type": "list",
                    "id": "var_1"
                }
            ],
            "cartesian_params": {
                "seed": ["6789"],
                "time_of_day": ["morning"],
                "variables": [
                    {
                        "values_list": [12],
                        "variable_id": "var_1"
                    }
                ],
                "weather_conditions": ["clear"],
                'terrain_conditions': ['Dry']
            },
            "dynamic_objects": [],
            "description": "description",
            "terrain": {"id": "hdm-SY10201842", "mode": ""},
            "name": "name",
            "simulation_termination": {"distance": -1, "timeout": 20},
            "spawn_objects": [
                {
                    "name": "MyCarsSpawn",
                    "type": "cars",
                    "object_count": 10,
                    "color": "#8e1208",
                    "use_full_physics": True,
                    "initial_speed": {
                        "min": 10,
                        "max": 20
                    },
                    "speed": {
                        "min": 20,
                        "max": 30
                    },
                    "politeness": {
                        "min": 20,
                        "max": 20
                    },
                    "time_to_collision": {
                        "min": 1.5,
                        "max": 1.5
                    },
                    "comfortable_braking": {
                        "min": 2,
                        "max": 2
                    },
                    "lane_change_speed": {
                        "min": 0.25,
                        "max": 0.25
                    },
                    "id": "spawn_object_0001",
                    "segments": [],
                    "shapes": [
                        {
                            "type": "polygon",
                            "id": "shapes_0",
                            "positions": [
                                {
                                    "id": "positions_0",
                                    "lat": 41.75340344505867,
                                    "lng": -116.95499092340472
                                },
                                {
                                    "id": "positions_1",
                                    "lat": 41.752570533510934,
                                    "lng": -116.93923629820353
                                },
                                {
                                    "id": "positions_2",
                                    "lat": 41.736301329084085,
                                    "lng": -116.93799376487736
                                },
                                {
                                    "id": "positions_3",
                                    "lat": 41.73661606556808,
                                    "lng": -116.95601552724843
                                }
                            ]
                        }
                    ],
                    "obj_type": "spawn_objects",
                    "distribution": [
                        {
                            'id': 'distribution_0',
                            "label": "Car-Generic Pickup Black",
                            "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Black",
                        },
                        {
                            'id': 'distribution_1',
                            "label": "Car-Generic Pickup Blue",
                            "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Blue",
                        }
                    ]
                }
            ],
            "movingObjects": [
                {
                    "obj_type": "movingObjects",
                    "name": "Pickup",
                    "id": "moving_object_0001",
                    "waypoints": [
                        {
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "id": "waypoints_0",
                            "position": {
                                "lat": 41.738451768511415,
                                "lng": -116.94811918510824
                            }
                        },
                        {
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "id": "waypoints_1",
                            "position": {
                                "lat": 41.738421768513415,
                                "lng": -116.94821918510824
                            }
                        },
                        {
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "id": "waypoints_2",
                            "position": {
                                "lat": 41.738381768511415,
                                "lng": -116.94811918810824
                            }
                        },
                        {
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "id": "waypoints_3",
                            "position": {
                                "lat": 41.738421768551415,
                                "lng": -116.94811918510824
                            }
                        },
                        {
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "id": "waypoints_4",
                            "position": {
                                "lat": 41.738471768511415,
                                "lng": -116.94871918710824
                            }
                        }
                    ],
                    "scripts": [
                        {
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setPathSpeed",
                            "actionValue": 1,
                            "id": "scripts_0",
                            "movingObjectId": "moving_object_0001"
                        },
                        {
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setPathAcceleration",
                            "actionValue": 0,
                            "id": "scripts_1",
                            "movingObjectId": "moving_object_0001"
                        },
                        {
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setOrientation",
                            "actionValue": 0,
                            "id": "scripts_2",
                            "movingObjectId": "moving_object_0001"
                        },
                        {
                            "movingObjectId": "moving_object_0001",
                            "readOnly": False,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 3,
                            "actionType": "setPathAcceleration",
                            "id": "scripts_3",
                            "actionValue": 0
                        },
                        {
                            "movingObjectId": "moving_object_0001",
                            "readOnly": False,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 3,
                            "actionType": "setPathAcceleration",
                            "id": "scripts_4",
                            "actionValue": 0
                        },
                        {
                            "movingObjectId": "moving_object_0001",
                            "readOnly": False,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setPathAcceleration",
                            "id": "scripts_5",
                            "actionValue": 0
                        }
                    ],
                    "type": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_White",
                    # TODO: Check if the field is MUST - "iconType": "car",
                    # TODO: Check if the field is MUST - "totalDistance": "15.67 m"
                }
            ],
            "ego_car": {
                "politeness": 20,
                "comfortable_braking": 2,
                "time_to_collision": 0,
                "distance_to_collision": 0,
                "lane_change_speed": 0.25,
                "sensors": [],
                "obj_type": "ego_car",
                "ego_car_sku": "LANEDET2",
                "initial_speed": 0,
                "desired_speed": 14,
                "scripts": [],
                "starting_point": {
                    "lane": -1,
                    "lng": -116.94811764560569,
                    "lat": 41.713600870159034,
                    "lastSectionID": 0,
                    "firstSectionID": 0,
                    "roadId": "0"
                },
            }
        }
        terrain = Terrain("hdm-SY10201842", "")
        ego_car = AIVehicle.create_ego_car(
            Position.create_position(lane=-1, lat=41.713600870159034, lng=-116.94811764560569, road_id="0",
                                     first_section_id=0, last_section_id=0), sku="LANEDET2",
            initial_speed=Variable.get_var_expression("myVar", 12, 34),
            desired_speed=14, time_to_collision=0, distance_to_collision=0)
        self.test_scenario = Scenario("name", "description",
                                      terrain,
                                      ego_car)
        cars_spawn = AIVehicle.create_spawn_area_cars(name="MyCarsSpawn", segments=[],
                                                      shapes=[{
                                                          "type": "polygon",
                                                          "positions": [
                                                              {
                                                                  "lat": 41.75340344505867,
                                                                  "lng": -116.95499092340472
                                                              },
                                                              {
                                                                  "lat": 41.752570533510934,
                                                                  "lng": -116.93923629820353
                                                              },
                                                              {
                                                                  "lat": 41.736301329084085,
                                                                  "lng": -116.93799376487736
                                                              },
                                                              {
                                                                  "lat": 41.73661606556808,
                                                                  "lng": -116.95601552724843
                                                              }
                                                          ]
                                                      }],
                                                      color=color_to_hex("Red"), object_count=10,
                                                      distribution=[
                                                          {
                                                              "label": "Car-Generic Pickup Black",
                                                              "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Black"
                                                          },
                                                          {
                                                              "label": "Car-Generic Pickup Blue",
                                                              "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Blue"
                                                          }
                                                      ], use_full_physics=True,
                                                      speed=range_object(20, 30), initial_speed=range_object(10, 20),
                                                      politeness_range=range_object(20, 20),
                                                      lane_change_speed_range=range_object(0.25, 0.25),
                                                      comfortable_braking=range_object(2,2),
                                                      time_to_collision_range=range_object(1.5, 1.5))
        self.test_scenario.add_spawn_object(cars_spawn)

        pickup_moving_object_scripts = [
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(3),
                                                    ActorScript.create_set_path_acceleration_action(0)),
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(3),
                                                    ActorScript.create_set_path_acceleration_action(0)),
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(0),
                                                    ActorScript.create_set_path_acceleration_action(0))
        ]
        pickup_moving_object_path    = [
            Position.create_moving_object_waypoint(lat=41.738451768511415, lng=-116.94811918510824, is_anchor=False),
            Position.create_moving_object_waypoint(lat=41.738421768513415, lng=-116.94821918510824, is_anchor=False),
            Position.create_moving_object_waypoint(lat=41.738381768511415, lng=-116.94811918810824, is_anchor=False),
            Position.create_moving_object_waypoint(lat=41.738421768551415, lng=-116.94811918510824, is_anchor=False),
            Position.create_moving_object_waypoint(lat=41.738471768511415, lng=-116.94871918710824, is_anchor=False)
        ]
        pickup_moving_object = AIVehicle.create_moving_object(name="Pickup", type="Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_White",
                                                              speed=1, acceleration=0, orientation=0,
                                                              scripts=pickup_moving_object_scripts, path=pickup_moving_object_path)
        self.test_scenario.add_moving_object(pickup_moving_object)
        self.test_scenario.add_variable(Variable("myVar", Variable.DataTypes.integer, [12]))
        self.test_scenario.set_rules(gen_scenario2("myVar", "myVar", "myVar"))
        to_compare = self.test_scenario.get_formula()

        # print(json.dumps(to_compare))
        self.assertDictEqual(to_compare, expected)

        api = CognataRequests("http://localhost:8100/v1", "admin2019", "Cognata2019")
        api.create_scenario(to_compare)

    def test_scenario_ego_all_scripts_WORKS(self):
        expected = {
            "cartesian_params": {
                "terrain_conditions": [
                    "Dry"
                ],
                "weather_conditions": [
                    "clear"
                ],
                "time_of_day": [
                    "morning"
                ],
                "seed": [
                    "6789"
                ],
                "variables": []
            },
            "terrain": {
                "id": "hdm-EU20201842",
                "mode": ""
            },
            "ego_car": {
                "ego_car_sku": "SINGLECA",
                "sensors": [],
                "desired_speed": 15,
                "initial_speed": 15,
                "lane_change_speed": 0.25,
                "time_to_collision": 1.5,
                "distance_to_collision": 10,
                "comfortable_braking": 2,
                "politeness": 20,
                "starting_point": {
                    "lat": 50.06080744365,
                    "lng": 8.658954785205426,
                    "roadId": "2",
                    "firstSectionID": 18,
                    "lastSectionID": 18,
                    "lane": -3
                },
                "scripts": [
                    {
                        "id": "scripts_0",
                        "simulationTimeTrigger": 3,
                        "actionType": "setDesiredSpeed",
                        "actionValue": 30,
                        "triggerType": "simulationTimeTrigger"
                    },
                    {
                        "id": "scripts_1",
                        "actionType": "moveLane",
                        "actionValue": 1,
                        "triggerType": "locationTrigger",
                        "lat": 50.06088406854497,
                        "lng": 8.659540386870505,
                        "lane": -2,
                        "roadId": "2",
                        "firstSectionID": 0,
                        "lastSectionID": 0
                    },
                    {
                        "id": "scripts_2",
                        "actionType": "setDriverAcceleration",
                        "triggerType": "timeToCollisionTrigger",
                        "timeToCollisionTrigger": 3,
                        "maxPedalVelocity": 2,
                        "acceleration": 4,
                        "isOn": True,
                        "MPVParamType": "const"
                    },
                    {
                        "id": "scripts_3",
                        "actionType": "sendMsgToClient",
                        "triggerType": "stableTrigger",
                        "targetSpeed": 10,
                        "speedTolerance": 1,
                        "speedDuration": 3,
                        "speedToleranceType": "abs",
                        "distanceUnits": 0,
                        "distanceToleranceType": "abs",
                        "distanceTolerance": 0,
                        "targetDistance": 4,
                        "value": "Value",
                        "param": "Key"
                    },
                    {
                        "id": "scripts_4",
                        "actionType": "logMessagesWithParam",
                        "triggerType": "relativeLocationTrigger",
                        "anchorRef": {
                            "lng": 8.68205226808338,
                            "lat": 50.061227660953165,
                            "name": "East Curve-Start"
                        },
                        "relativeDistance": 100,
                        "laneOffset": 0,
                        "headway": 90,
                        "value": "Value",
                        "param": "Key"
                    },
                    {
                        "id": "scripts_5",
                        "actionType": "logMessage",
                        "actionValue": "Message",
                        "triggerType": "speedTrigger",
                        "speedTriggerType": "over",
                        "speed": 23
                    },
                    {
                        "id": "scripts_6",
                        "actionType": "invokeEvent",
                        "actionValue": "EventToInvoke",
                        "triggerType": "eventTrigger",
                        "listenToMessage": "EventToListen",
                        "listenToObject": "",
                        "delayInSeconds": 0
                    },
                    {
                        "id": "scripts_7",
                        "actionType": "inLaneOffset",
                        "triggerType": "timeToLocationTrigger",
                        "lat": 50.06109069686521,
                        "lng": 8.660044642165303,
                        "lane": -1,
                        "roadId": "2",
                        "time": 0,
                        "offset": 1.5,
                        "offsetDuration": 20
                    },
                    {
                        "id": "scripts_8",
                        "actionType": "setSteering",
                        "triggerType": "timeToLocationTrigger",
                        "transitionDuration": 2,
                        "steer": 1,
                        "anchorRef": {
                            "lng": 8.660671067425286,
                            "lat": 50.06107671216032,
                            "name": "West Curve-Start"
                        },
                        "time": 0
                    },
                    {
                        "id": "scripts_9",
                        "actionType": "setTurningSignaling",
                        "triggerType": "eventTrigger",
                        "turnType": 1,
                        "listenToMessage": "EventToListen",
                        "listenToObject": "",
                        "delayInSeconds": 0
                    },
                    {
                        "id": "scripts_10",
                        "simulationTimeTrigger": 0,
                        "actionType": "requestEndOfSimulation",
                        "triggerType": "simulationTimeTrigger",
                        "reason": "I'm tired"
                    },
                    {
                        "id": "scripts_11",
                        "simulationTimeTrigger": 0,
                        "actionType": "setCollisionAvoidance",
                        "triggerType": "simulationTimeTrigger",
                        "collisionAvoidanceDuration": 7,
                        "collisionAvoidanceSwitch": "On"
                    },
                    {
                        "id": "scripts_12",
                        "actionType": "setDesiredSpeed",
                        "actionValue": 30,
                        "triggerType": "relativeLocationTrigger",
                        "anchorRef": {
                            "name": "Moving object 0001 Anchor 1",
                            "lat": 50.06099067191939,
                            "lng": 8.662040488561617,
                            "isMovingObjectIndex": 1,
                            "isMovingObjectId": "moving_object_0001"
                        },
                        "relativeDistance": 0,
                        "laneOffset": 0,
                        "headway": 0
                    },
                    {
                        "id": "scripts_13",
                        "actionType": "setDesiredSpeed",
                        "actionValue": 30,
                        "triggerType": "timeToLocationTrigger",
                        "anchorRef": {
                            "name": "Moving object 0001 Anchor 1",
                            "lat": 50.06099067191939,
                            "lng": 8.662040488561617,
                            "isMovingObjectIndex": 1,
                            "isMovingObjectId": "moving_object_0001"
                        },
                        "time": 0
                    }

                ],
                "ending_point": {
                    "lat": 50.061276661592494,
                    "lng": 8.659062953665853,
                    "roadId": "2",
                    "firstSectionID": 4,
                    "lastSectionID": 4,
                    "segmentId": "2_4_4_-3",
                    "lane": -3
                },
                "obj_type": "ego_car",
            },
            "spawn_objects": [],
            "simulation_termination": {
                "timeout": 10,
                "distance": -1
            },
            "description": "description",
            "name": "test_scenario_ego_all_scripts_WORKS",
            "analysis_rules": [],
            # Todo: Add to scenario!
            # "intersections": [],
            # Todo: Add to scenario!
            # "tags": [],
            # Todo: Add to scenario!
            # "scenarioMessages": [
            #     "EventToListen",
            #     "EventToInvoke"
            # ],
            "variables": [],
            "dynamic_objects": [],
            "movingObjects": [
                {
                    "obj_type": "movingObjects",
                    "name": "Moving object 0001",
                    "id": "moving_object_0001",
                    "waypoints": [
                        {
                            "id": "waypoints_0",
                            "isAnchor": False,
                            "movingObjectId": "moving_object_0001",
                            "position": {
                                "lat": 50.06093228189932,
                                "lng": 8.661652207374575
                            }
                        },
                        {
                            "id": "waypoints_1",
                            "isAnchor": True,
                            "movingObjectId": "moving_object_0001",
                            "position": {
                                "lat": 50.06099067191939,
                                "lng": 8.662040488561617
                            },
                            "anchorName": "Moving object 0001 Anchor 1"
                        }
                    ],
                    "scripts": [
                        {
                            "id": "scripts_0",
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setPathSpeed",
                            "actionValue": 1,
                            "movingObjectId": "moving_object_0001"
                        },
                        {
                            "id": "scripts_1",
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setPathAcceleration",
                            "actionValue": 0,
                            "movingObjectId": "moving_object_0001"
                        },
                        {
                            "id": "scripts_2",
                            "readOnly": True,
                            "triggerType": "wayPointTrigger",
                            "triggerValue": 0,
                            "actionType": "setOrientation",
                            "actionValue": 0,
                            "movingObjectId": "moving_object_0001"
                        }
                    ],
                    "type": "General_Props/Characters_With_Bikes/Nakish_With_Bike",
                }
            ],
            # Todo: Add to scenario!
            # "strict_spawn": True,
            # Todo: Add to scenario!
            # "synthetic_objects": []
        }

        terrain = Terrain("hdm-EU20201842", "")

        nakisha_waypoints = [
            Position.create_moving_object_waypoint(lat=50.06093228189932, lng=8.661652207374575, is_anchor=False),
            Position.create_moving_object_waypoint(lat=50.06099067191939, lng=8.662040488561617,
                                                   is_anchor=True, anchor_name="Moving object 0001 Anchor 1")
        ]
        nakisha_moving_object = AIVehicle.create_moving_object(
            name="Moving object 0001", type="General_Props/Characters_With_Bikes/Nakish_With_Bike",
            speed=1, acceleration=0, orientation=0, scripts=[], path=nakisha_waypoints
        )

        ego_spawn = Position.create_position(lane=-3, lat=50.06080744365, lng=8.658954785205426, road_id="2",
                                             first_section_id=18, last_section_id=18)
        ego_destination = Position.create_position(lane=-3, lat=50.061276661592494, lng=8.659062953665853, road_id="2",
                                                   first_section_id=4, last_section_id=4, segment_id="2_4_4_-3")

        ego_scripts = [
            ActorScript.create_ego_car_script(ActorScript.create_simulation_time_trigger(3),
                                              ActorScript.create_set_desired_speed_action(30)),
            ActorScript.create_ego_car_script(ActorScript.create_location_trigger(
                Position.create_position(lane=-2, lng=8.659540386870505, lat=50.06088406854497, road_id="2",
                                         first_section_id=0, last_section_id=0)),
                                              ActorScript.create_move_lane_action(1)),
            ActorScript.create_ego_car_script(ActorScript.create_time_to_collision_trigger(3),
                                              ActorScript.create_set_acceleration_action(is_on=True, acceleration=4,
                                                                                         max_pedal_velocity=2,
                                                                                         mpv_param_type=ActorScript.MaxPedalType.const)),
            ActorScript.create_ego_car_script(ActorScript.create_stable_trigger(target_speed=10, speed_tolerance=1,
                                                                                speed_tolerance_type=ActorScript.ToleranceType.abs,
                                                                                speed_duration=3, target_distance=4,
                                                                                distance_units=ActorScript.StableTriggerDistanceUnits.meters,
                                                                                distance_tolerance=0,
                                                                                distance_tolerance_type=ActorScript.ToleranceType.abs),
                                              ActorScript.create_send_msg_to_client_action(param="Key", value="Value")),
            ActorScript.create_ego_car_script(ActorScript.create_relative_location_trigger(headway=90, lane_offset=0,
                                                                                           relative_distance=100,
                                                                                           anchor_ref="East Curve-Start",
                                                                                           lat=50.061227660953165,
                                                                                           lng=8.68205226808338),
                                              ActorScript.create_log_message_with_param_action(param="Key", value="Value")),
            ActorScript.create_ego_car_script(ActorScript.create_speed_trigger(speed=23,
                                                                               check_type=ActorScript.SpeedTriggerCheckType.over),
                                              ActorScript.create_log_message_action("Message")),
            ActorScript.create_ego_car_script(ActorScript.create_event_trigger("EventToListen"),
                                              ActorScript.create_invoke_event_action("EventToInvoke")),
            ActorScript.create_ego_car_script(ActorScript.create_time_to_location_position_trigger(time_to_location=0,
                                                                                                   lat=50.06109069686521,
                                                                                                   lng=8.660044642165303,
                                                                                                   lane=-1, road_id="2"),
                                              ActorScript.create_in_lane_offset_action(offset=1.5, offset_duration=20)),
            ActorScript.create_ego_car_script(ActorScript.create_time_to_location_anchor_trigger(time_to_location=0,
                                                                                                 lat=50.06107671216032,
                                                                                                 lng=8.660671067425286,
                                                                                                 anchor_name="West Curve-Start"),
                                              ActorScript.create_set_steering_action(steering=1, transition_duration=2)),
            ActorScript.create_ego_car_script(ActorScript.create_event_trigger(event_id="EventToListen"),
                                              ActorScript.create_set_turning_signal_action(ActorScript.TurningSignalType.right)),
            ActorScript.create_ego_car_script(ActorScript.create_simulation_time_trigger(0),
                                              ActorScript.create_end_simulation_request_action("I'm tired")),
            ActorScript.create_ego_car_script(ActorScript.create_simulation_time_trigger(0),
                                              ActorScript.create_set_collision_avoidance_action(
                                                  collision_avoidance_switch=True,
                                                  collision_avoidance_duration=7)),
            ActorScript.create_ego_car_script(ActorScript.create_relative_location_trigger(
                headway=0, lane_offset=0, relative_distance=0, anchor_ref="Moving object 0001 Anchor 1",
                lat=50.06099067191939, lng=8.662040488561617, waypoint_id=1, waypoint_moving_obj_id="moving_object_0001"),
                                              ActorScript.create_set_desired_speed_action(30)),
            ActorScript.create_ego_car_script(ActorScript.create_time_to_location_waypoint_trigger(
                time_to_location=0, waypoint_name="Moving object 0001 Anchor 1",
                lat=50.06099067191939, lng=8.662040488561617, waypoint_id=1, waypoint_moving_obj_id="moving_object_0001"),
                                              ActorScript.create_set_desired_speed_action(30))
        ]
        ego_car = AIVehicle.create_ego_car(
            spawn_pos=ego_spawn, dest_pos=ego_destination,
            initial_speed=15, desired_speed=15, scripts=ego_scripts, sku="SINGLECA")
        self.test_scenario = Scenario(name="test_scenario_ego_all_scripts_WORKS", description="description",
                                      terrain=terrain, ego_car=ego_car, timeout=10)

        self.test_scenario.add_moving_object(nakisha_moving_object)
        to_compare = self.test_scenario.get_formula()

        # print(json.dumps(to_compare))
        self.assertDictEqual(to_compare, expected)

    @unittest.expectedFailure
    def test_scenario_variables_identification_FAILS(self):
        self.test_scenario = Scenario("name", "description",
                                      {"TerrainConfiguration": "Honda"},
                                      {"initial_speed": 12, "desired_speed": 13})
        self.assertEqual(0, 1)


if __name__ == "__main__":
    unittest.main()
