# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential


class Terrain:
    def __init__(self, map_id, mode="", classes_to_exclude: list = None):
        if classes_to_exclude is None:
            classes_to_exclude = []
        self.id = map_id
        self.mode = mode
        self.classes_to_exclude = classes_to_exclude

    def to_json(self):
        """
        build terrain json object
        """
        return {
            "id": self.id,
            "mode": self.mode,
            "excludedSceneClasses": self.classes_to_exclude
        }
