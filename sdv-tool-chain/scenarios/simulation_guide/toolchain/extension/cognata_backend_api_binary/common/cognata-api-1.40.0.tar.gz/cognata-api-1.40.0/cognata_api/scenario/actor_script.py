# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from enum import Enum

from cognata_api.scenario.position import create_relative_location_object, create_anchor_reference_object


def create_ego_car_script(trigger_params, action_params):
    script = create_script(trigger_params=trigger_params, action_params=action_params)
    return script


def create_dynamic_object_script(trigger_params, action_params):
    script = create_script(trigger_params=trigger_params, action_params=action_params)
    return script


def create_moving_object_script(trigger_params,action_params):
    script = create_script(trigger_params=trigger_params, action_params=action_params)
    return script


def create_script(trigger_params, action_params):
    rv = {}
    for key in trigger_params.keys():
        rv[key] = trigger_params[key]
    for key in action_params.keys():
        rv[key] = action_params[key]
    return rv


def create_simulation_time_trigger(time):
    return {"triggerType": "simulationTimeTrigger", "simulationTimeTrigger": time}


def create_waypoint_trigger(waypoint_id):
    return {"triggerType": "wayPointTrigger",
            "triggerValue": waypoint_id}


def create_event_trigger(event_id, event_emitter="", delay_in_seconds=0):
    return {"triggerType": "eventTrigger",
            "listenToMessage": event_id,
            "listenToObject": event_emitter,
            "delayInSeconds": delay_in_seconds}


def create_location_trigger(position):
    rv = {"triggerType": "locationTrigger"}
    for key in position:
        rv[key] = position[key]
    return rv


def create_time_to_collision_trigger(ttc):
    return {"triggerType": "timeToCollisionTrigger",
            "timeToCollisionTrigger": ttc}


# todo: is this for waypoints only or any XY?
def __create_time_to_location_trigger(time_to_location, lat=None, lng=None, lane=None, road_id=None, anchor_name=None,
                                      waypoint_id=None, waypoint_moving_obj_id=None, anchor_reference_obj=None):
    rv = {
        "triggerType": "timeToLocationTrigger",
        "time": time_to_location
    }
    is_relative = anchor_name is not None or anchor_reference_obj is not None
    if is_relative:
        if anchor_reference_obj is None:
            anchor_reference_obj = create_anchor_reference_object(anchor_name=anchor_name, lat=lat, lng=lng,
                                                                  waypoint_id=waypoint_id,
                                                                  waypoint_moving_obj_id=waypoint_moving_obj_id)
        rv["anchorRef"] = anchor_reference_obj
    else:
        rv["lat"] = lat
        rv["lng"] = lng
        rv["lane"] = lane
        rv["roadId"] = road_id

    rv["isRelative"] = is_relative
    return rv


def create_time_to_location_position_trigger(time_to_location, lat, lng, lane, road_id):
    return __create_time_to_location_trigger(time_to_location=time_to_location, lat=lat, lng=lng,
                                             lane=lane, road_id=road_id)


def create_time_to_location_waypoint_trigger(time_to_location, lat=None, lng=None,
                                             waypoint_name=None, waypoint_id=None, waypoint_moving_obj_id=None,
                                             relative_location_obj=None):
    return __create_time_to_location_trigger(time_to_location=time_to_location, lat=lat, lng=lng,
                                             anchor_name=waypoint_name,
                                             waypoint_id=waypoint_id, waypoint_moving_obj_id=waypoint_moving_obj_id,
                                             anchor_reference_obj=relative_location_obj)


def create_time_to_location_anchor_trigger(time_to_location, lat=None, lng=None, anchor_name=None, relative_location_obj=None):
    return __create_time_to_location_trigger(time_to_location=time_to_location, lat=lat, lng=lng, anchor_name=anchor_name,
                                             anchor_reference_obj=relative_location_obj)


class SpeedTriggerCheckType(Enum):
    over = 1
    under = 2


class ToleranceType(Enum):
    abs = 1
    rel = 2


class StableTriggerDistanceUnits(Enum):
    meters  = 0
    seconds = 1


def create_speed_trigger(speed, check_type):
    """

    :param float speed:
    :param SpeedTriggerCheckType check_type:
    :return:
    """
    return {"triggerType": "speedTrigger",
            "speed": speed,
            "speedTriggerType": check_type.name}


def create_stable_trigger(target_speed, speed_tolerance, speed_tolerance_type, speed_duration,
                          target_distance, distance_units, distance_tolerance, distance_tolerance_type):
    """
    Create stable trigger object (JSON)
    :param float target_speed:
    :param float speed_tolerance:
    :param ToleranceType speed_tolerance_type:
    :param float speed_duration:
    :param float target_distance:
    :param StableTriggerDistanceUnits distance_units:
    :param float distance_tolerance:
    :param ToleranceType distance_tolerance_type:
    :return:
    """
    return {"triggerType": "stableTrigger",
            "targetSpeed": target_speed,
            "speedTolerance" : speed_tolerance,
            "speedToleranceType": speed_tolerance_type.name,
            "speedDuration": speed_duration,
            "targetDistance": target_distance,
            "distanceUnits": distance_units.value,
            "distanceTolerance": distance_tolerance,
            "distanceToleranceType": distance_tolerance_type.name}


def create_relative_location_trigger(headway, lane_offset, relative_distance,
                                     anchor_ref=None, lat=None, lng=None, waypoint_id=None, waypoint_moving_obj_id=None,
                                     anchor_reference_object=None):
    # Can be called with either:
    # # params for creating the relative location object
    # # a given relative location object
    relative_location_obj = create_relative_location_object(headway=headway, lane_offset=lane_offset,
                                                            relative_distance=relative_distance,anchor_name=anchor_ref,
                                                            lat=lat, lng=lng, waypoint_id=waypoint_id,
                                                            waypoint_moving_obj_id=waypoint_moving_obj_id,
                                                            anchor_reference_object=anchor_reference_object)
    relative_location_obj.update({"triggerType": "relativeLocationTrigger"})
    return relative_location_obj


def create_simple_action(action_type, action_value):
    return {"actionType": action_type,
            "actionValue": action_value}


def __create_simple_action(action_type, action_value):
    return {"actionType": action_type,
            "actionValue": action_value}


def create_move_lane_action(lanes_cnt):
    return __create_simple_action("moveLane", lanes_cnt)


def create_in_lane_offset_action(offset, offset_duration):
    return { "actionType": "inLaneOffset",
             "offset": offset,
             "offsetDuration": offset_duration}


def create_set_desired_speed_action(desired_speed):
    return __create_simple_action("setDesiredSpeed", desired_speed)


def create_set_steering_action(steering, transition_duration):
    return {"actionType": "setSteering",
            "steer": steering,
            "transitionDuration": transition_duration}


def create_set_path_speed_action(path_speed):
    return __create_simple_action("setPathSpeed",path_speed)


def create_set_path_acceleration_action(path_acceleration):
    return __create_simple_action("setPathAcceleration",path_acceleration)


def create_set_orientation_over_path_action(orientation):
    return __create_simple_action("setOrientation", orientation)


def create_set_socket_orientation_action(offset_x, offset_y, offset_z, offset_yaw, offset_pitch, offset_roll):
    return {"actionType": "socketOrientation",
            "offsetX": offset_x,
            "offsetY": offset_y,
            "offsetZ": offset_z,
            "rotationYaw": offset_yaw,
            "rotationPitch": offset_pitch,
            "rotationRoll": offset_roll}


def create_play_animation_action(animation_name, animation_index, animation_speed, subsystem = None):
    action = {"actionType": "playAnimation",
            "animationName": animation_name,
            "animationIndex": animation_index,
            "animationSpeed": animation_speed}
    if (subsystem):
        action["subSystem"] = subsystem
    return action

def create_stop_animation_action(animation_name, animation_index, subsystem = None):
    action = {"actionType": "stopAnimation",
            "animationName": animation_name,
            "animationIndex": animation_index}
    if (subsystem):
        action["subSystem"] = subsystem
    return action


def create_end_simulation_request_action(reason):
    return {"actionType": "requestEndOfSimulation",
            "reason": reason}


def create_set_destination_action(destination_anchor):
    if isinstance(destination_anchor, str):
        destination_anchor = create_anchor_reference_object(anchor_name=destination_anchor)
    return {"actionType": "setDestination",
            "anchorRefAction": destination_anchor}


def create_invoke_event_action(event_id):
    return __create_simple_action("invokeEvent",event_id)


def create_log_message_action(message):
    return __create_simple_action("logMessage", message)


def create_log_message_with_param_action(param, value):
    return {"actionType": "logMessagesWithParam",
            "param": param,
            "value": value}


def create_send_msg_to_client_action(param, value):
    return {"actionType": "sendMsgToClient",
            "param": param,
            "value": value}


class MaxPedalType(Enum):
    const  = 0
    deltaV = 1


def create_set_acceleration_action(is_on, acceleration, max_pedal_velocity, mpv_param_type=MaxPedalType.deltaV):
    """

    :param bool is_on:
    :param float acceleration:
    :param float max_pedal_velocity:
    :param MaxPedalType mpv_param_type:
    :return:
    """
    return {"actionType": "setDriverAcceleration",
            "isOn": is_on,
            "acceleration": acceleration,
            "MPVParamType": mpv_param_type.name,
            "maxPedalVelocity": max_pedal_velocity
            }


class TurningSignalType(Enum):
    off = 0
    right = 1
    left = 2
    hazard = 3


def create_set_turning_signal_action(signal_type):
    """

    :param TurningSignalType signal_type:
    :return:
    """
    return {"actionType": "setTurningSignaling",
            "turnType": signal_type.value}


def create_set_collision_avoidance_action(collision_avoidance_switch, collision_avoidance_duration):
    """

    :param bool collision_avoidance_switch:
    :param float collision_avoidance_duration:
    :return:
    """
    return {"actionType": "setCollisionAvoidance",
            "collisionAvoidanceSwitch": "On" if collision_avoidance_switch else "Off",
            "collisionAvoidanceDuration": collision_avoidance_duration}


def create_set_gas_action(pedal_pressure):
    """
    Create Set Gas action
    :param pedal_pressure: Pressure applied to gas pedal. Range: [0.0, 1.0]
    :type pedal_pressure: float
    """
    return {
        "actionType": "setGas",
        "pedalPressure": pedal_pressure
    }


def create_set_brake_action(pedal_pressure):
    """
    Create Set Brake action
    :param pedal_pressure: Pressure applied to brake pedal. Range: [0.0, 1.0]
    :type pedal_pressure: float
    """
    return {
        "actionType": "setBrake",
        "pedalPressure": pedal_pressure
    }


# Consts for setDrivingMode action
c_DRIV_MOD_AI       = 0
c_DRIV_MOD_MANUAL   = 1


def _create_set_driving_mode_action(mode):
    """
    Internal function - Create Set Driving Mode action
    :param mode: Mode - 0=AI, 1=Manual
    :type mode: int
    """
    return {
        "actionType": "setDrivingMode",
        "driveMode": mode
    }


def create_set_driving_mode_manual_action():
    """
    Create Set Driving Mode action set to "Manual"
    """
    return _create_set_driving_mode_action(c_DRIV_MOD_MANUAL)


def create_set_driving_mode_ai_action():
    """
    Create Set Driving Mode action set to "AI"
    """
    return _create_set_driving_mode_action(c_DRIV_MOD_AI)


# Consts for setGear action
c_GEAR_MOD_DRIVE    = 0
c_GEAR_MOD_REVERSE  = 1


def _create_set_gear_action(mode):
    """
    Internal function - Create Set Gear action
    :param mode: Mode - 0=Drive, 1=Reverse
    :type mode: int
    """
    return {
        "actionType": "setGear",
        "gearMode": mode
    }


def create_set_gear_drive_action():
    """
    Create Set Gear action set to "Drive"
    """
    return _create_set_gear_action(c_GEAR_MOD_DRIVE)


def create_set_gear_reverse_action():
    """
    Create Set Gear action set to "Reverse"
    """
    return _create_set_gear_action(c_GEAR_MOD_REVERSE)
