##Please note, there is a repo within a repo(submodule) in this project, it is not yet widely used across Cognata, so feel free to ask for help; as a beginning, after cloning perform the following commands in order to be fully synced:
```$ git clone git@bitbucket.org:cognatadev/scenariosgenerator.git ScenariosGenerator # clone of parent repo into ScenariosGenerator
$ cd ScenariosGenerator
$ git submodule init
$ git submodule update --recursive --remote # Notice Telegram combines two sequential dashes (-) into a big one, so add one in case needed
```

####Link to the repo's overview page in bitbucket:
https://bitbucket.org/cognatadev/scenariosgenerator/src/master/

## Setting up development environment
1. Create conda environment - python 3.7:
    ```commandline
    conda create --name <ENV-NAME> python=3.7
    ```
2. Install requirements:
    ```commandline
    pip install -r requirements.txt
    ```
3. Install package in edit mode:
    ```commandline
    python setup.py develop
    ```
## Jupyter notebook
 ###### To use jupyter notebook we need to install our env as kernel, follow the steps:

1. Activate the relevant conda environment:
    ```commandline
    conda activate <ENV-NAME>
    ```
2. Install ipykernel:
    ```commandline
    conda install -c anaconda ipykernel
    ```
3. Add current conda env as a kernel:
    ```commandline
    python -m ipykernel install --user --name=<KERNEL-NAME>
    ```
4. Open jupyter notebook:
    ```commandline
   jupyter notebook
    ```
