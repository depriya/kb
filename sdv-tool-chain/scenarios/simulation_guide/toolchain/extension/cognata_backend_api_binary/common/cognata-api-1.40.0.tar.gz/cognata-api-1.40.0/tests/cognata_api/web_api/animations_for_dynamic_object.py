import json
import os
import os.path as osp

import cognata_api.scenario.position as Position
import cognata_api.scenario.ai_vehicle as AiVehicle
from cognata_api.scenario.scenario import Scenario
from cognata_api.scenario.terrain import Terrain
import cognata_api.scenario.actor_script as Script
from cognata_api.web_api.cognata_api_wrapper import CognataRequests

cognata_api = CognataRequests(client_api_url="", user="", password="")

# ++++++++++++++++++++++++++++++++++++++++++

# Definitions Section

test_name = osp.basename(__file__).split(".py")[0]
test_number = "DRPD-7236"
test_description = "Time: 2, 4, 6, 8, Steering: -1, 1, 0, 1(slowly)"
full_name = test_number + ": " + test_name
group_name = osp.abspath(__file__).split(os.sep)[5]

maps = {x["name"]: x["sku"] for x in cognata_api.get_maps_list(lite=True, readOnly=True)}
presets = {x['name']: x['sku'] for x in cognata_api.get_ego_cars_list()}

terrain = Terrain(maps["Synthetic Single"])

ego_behaviour = AiVehicle.create_driving_behaviour_object(0, 0)
ego_pos = Position.create_position(lat=41.731749071066155, lng=-116.94808188825849,)
ego_car = AiVehicle.create_ego_car_v2(
    spawn_pos=ego_pos,
    driving_behaviour=ego_behaviour,
    sku=presets["Single_Cam"],
    scripts=[])

assets = cognata_api.get_asset_list(lite=True)
# mapping sku with brand id
assets_mapping = {asset["brandID"]: asset["sku"] for asset in assets}
# choosing an asset SKU by brandID (choose as needed)
sample_asset_sku = assets_mapping["Vehicles/Emergency_Vehicles/Light_Commercial_Ambulance"]
# fetching full data of an asset by SKU
asset_data = cognata_api.find_asset(sample_asset_sku)
# fetching animation from asset (choose as needed)
animation = asset_data["properties"]["animationsActions"][1]

dynamic_pos = Position.create_position(lat=41.731549071066155, lng=-116.94808188825849)
dy_play_anim = Script.create_dynamic_object_script(Script.create_simulation_time_trigger(2),
                                                   Script.create_play_animation_action(animation["animationName"], animation["actionIndex"], 1, animation["subSystem"]))
dy_stop_anim = Script.create_dynamic_object_script(Script.create_simulation_time_trigger(4),
                                                   Script.create_stop_animation_action(animation["animationName"], animation["actionIndex"], animation["subSystem"]))
dyn_behaviour = AiVehicle.create_driving_behaviour_object(initial_speed=0, desired_speed=0)
dyn = AiVehicle.create_dynamic_car_v2(dynamic_pos,
                                      None,
                                      False,
                                      type="Vehicles/Emergency_Vehicles/Light_Commercial_Ambulance",
                                      driving_behaviour=dyn_behaviour,
                                      scripts=[dy_play_anim, dy_stop_anim])

scene = Scenario(full_name, test_description, terrain, ego_car, timeout=10)
scene.add_dynamic_object(dyn)
Simulation = cognata_api.generate_simulation(scene.get_formula())
sce_id = cognata_api.get_simulation_run_id(Simulation)


