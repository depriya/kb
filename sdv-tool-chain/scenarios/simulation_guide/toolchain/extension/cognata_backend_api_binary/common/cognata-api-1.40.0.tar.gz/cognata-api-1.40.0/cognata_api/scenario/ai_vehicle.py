# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import deprecation
import logging
import sys

import cognata_api
import cognata_api.scenario.actor_script as ActorScript
import cognata_api.scenario.position as Position
import cognata_api.scenario.despawn_options as DespawnOptions
import cognata_api.scenario.attach_to_options as AttachToOptions
import cognata_api.scenario.spawning_repeat as SpawningRepeatOptions

# Configure static variables for module
this = sys.modules[__name__]
this.STATIC_DYNAMIC_OBJECTS_CNT = 1
this.STATIC_MOVING_OBJECTS_CNT  = 1
this.STATIC_SPAWN_OBJECTS_CNT   = 1
DEFAULT_DRIVER_MODEL = "STANDARD"
DEFAULT_DESPAWN_OPTIONS = { "on_exit_perimeter": DespawnOptions.DespawnMode.DONT_DESPAWN.value, "grace_time": 2.0 }
DEFAULT_SPAWN_REPEAT_OPTIONS = { "repeat_options": SpawningRepeatOptions.RepeatOptions.SINGLE.value, 
                                "spawn_location": SpawningRepeatOptions.SpawnLocation.ANY.value, 
                                "interval": 0.0 }

@deprecation.deprecated(details='Please use create_ego_car_v2()',
                        deprecated_in="1.5.17", current_version=cognata_api.__version__)
def create_ego_car(spawn_pos, sku, dest_pos=None, initial_speed=15, desired_speed=15, comfortable_braking=2,
                   time_to_collision=1.5, distance_to_collision=10, lane_change_speed=0.25,
                   scripts=None, relative_position_obj=None, end_simulation_at_dest=True, car_physics_sku=None):
    # This functions is replaced by its _v2
    # We keep this function with the same API for backward compatibility, but will remove it in the future.
    driving_behaviour = create_driving_behaviour_object(initial_speed=initial_speed, desired_speed=desired_speed,
                                                        comfortable_braking=comfortable_braking,
                                                        time_to_collision=time_to_collision,
                                                        distance_to_collision=distance_to_collision,
                                                        lane_change_speed=lane_change_speed, politeness=20)
    return create_ego_car_v2(spawn_pos=spawn_pos, sku=sku, dest_pos=dest_pos, driving_behaviour=driving_behaviour,
                             scripts=scripts, relative_position_obj=relative_position_obj,
                             end_simulation_at_dest=end_simulation_at_dest, car_physics_sku=car_physics_sku)

# TODO: rename function name to a proper name
def create_ego_car_v2(spawn_pos, sku, driving_behaviour=None, dest_pos=None,
                      scripts=None, relative_position_obj=None,
                      end_simulation_at_dest=True, car_physics_sku=None, driver_model=None):
    if scripts is None:
        scripts = []
    if relative_position_obj:
        spawn_pos.update(relative_position_obj)  # Merge both objects
    if driver_model is None:
        driver_model = DEFAULT_DRIVER_MODEL
    positions = [spawn_pos]
    if dest_pos:
        positions.append(dest_pos)
        # Add default script for set destination relative to EgoCar end
        end_dest_script = ActorScript.create_ego_car_script(
            __create_implicit_script_trigger(),
            __create_end_point_action("EgoCar")
        )
        scripts = [end_dest_script, *scripts]
        if end_simulation_at_dest:
            end_of_sim_script = ActorScript.create_ego_car_script(
                ActorScript.create_relative_location_trigger(
                    headway=0, lane_offset=0, relative_distance=0, anchor_ref="EgoCar end",
                    lat=dest_pos.get("lat"), lng=dest_pos.get("lng")
                ),
                ActorScript.create_end_simulation_request_action("Reached end point")
            )
            scripts = [end_of_sim_script, *scripts]
    if not driving_behaviour:
        driving_behaviour = create_driving_behaviour_object()

    ego = {
        "starting_point": spawn_pos,
        "ending_point": dest_pos,
        "sensors": [],
        "obj_type": "ego_car",
        "ego_car_sku": sku,
        "car_physics_preset_sku": car_physics_sku,
        "scripts": scripts,
        "driver_model": driver_model
    }
    ego.update(driving_behaviour)
    # Validate positions format
    for p in positions:
        for coord in ["lat", "lng"]:
            if coord not in p:
                raise RuntimeError(
                    "ego_car position must contain lat and lng fields. Otherwise won't be presented in UI"
                )
    return {k: v for k, v in ego.items() if v is not None}

@deprecation.deprecated(details='Please use create_dynamic_car_v2()')
def create_dynamic_car(spawn_pos, dest_pos, is_pos_relative_obj, initial_speed, desired_speed,
                       scripts, type="Vehicles/Cars/Generic_SUV/Prefabs/Generic_SUV_White",
                       icon="sedan", name=None, car_physics_sku=None):
    # This functions is replaced by its _v2
    # We keep this function with the same API for backward compatibility, but will remove it in the future.
    driving_behaviour = create_driving_behaviour_object(initial_speed=initial_speed, desired_speed=desired_speed)
    return create_dynamic_car_v2(spawn_pos=spawn_pos, dest_pos=dest_pos, is_pos_relative_obj=is_pos_relative_obj,
                                 scripts=scripts, type=type, driving_behaviour=driving_behaviour, icon=icon, name=name,
                                 car_physics_sku=car_physics_sku)

# TODO: rename function name to a proper name
def create_dynamic_car_v2(spawn_pos, dest_pos, is_pos_relative_obj,
                          scripts, type="Vehicles/Cars/Generic_SUV/Prefabs/Generic_SUV_White",
                          driving_behaviour=None, icon="sedan", name=None, car_physics_sku=None, driver_model=None):
    dynamic_object_id = "dynamic_object_{:04}".format(this.STATIC_DYNAMIC_OBJECTS_CNT)
    if name is None:
        name = f"Dynamic object {this.STATIC_DYNAMIC_OBJECTS_CNT:04}"
    if driver_model is None:
        driver_model = DEFAULT_DRIVER_MODEL
    if not scripts:
        scripts = []
    if not isinstance(scripts, list):
        # As seen in the formula, the dynamic object's scripts is an object whose keys are sequential numbers
        logging.error("scripts must be of type list!")
        raise ValueError("scripts is not a list")
    if not driving_behaviour:
        driving_behaviour = create_driving_behaviour_object()

    # Not like EgoCar or Spawn Objects, Dynamic Objects structure expecting driver_model to be inside driving behavior
    driving_behaviour['driver_model'] = driver_model
    position_obj = {}
    if spawn_pos:
        position_obj["start"] = spawn_pos
    if dest_pos:
        position_obj["end"] = dest_pos
        scripts.append(
            ActorScript.create_dynamic_object_script(
                __create_implicit_script_trigger(),
                __create_end_point_action(name)
            )
        )
    if is_pos_relative_obj:
        if "anchorRef" not in is_pos_relative_obj:
            is_pos_relative_obj["anchorRef"] = Position.create_anchor_reference_object(anchor_name="Ego", lat=0, lng=0)
        position_obj.update(is_pos_relative_obj)

    dyn = {
        "id": dynamic_object_id,
        "position": position_obj,
        "name": name,
        "obj_type": "dynamic_objects",
        "type": type,
        "icon": icon,
        "drivingBehavior": driving_behaviour,
        "scripts": scripts,
        "physicsPresetSku": car_physics_sku
    }
    this.STATIC_DYNAMIC_OBJECTS_CNT += 1
    return dyn

def create_moving_object(name, type, speed, acceleration, orientation, scripts=None, path=None,
                         parent_obj_data=None, socket_data=None):
    """
    Create moving object that will finally be added to scenario
    :param name: Moving object name
    :type name: str
    :param type: moving object brandID (Needs to be retrieved from catalog)
    :type type: str
    :param speed: initial speed over path
    :type speed: float
    :param acceleration: initial acceleration over path
    :type acceleration: float
    :param orientation: initial orientation relative to path
    :type orientation: float
    :param scripts: moving object scripts list
    :type scripts: list
    :param path: moving object waypoints list
    :type path: list of waypoints
    :param parent_obj_data: parent moving object data. Id, socket index and name. Required only on child MO
    :type parent_obj_data: dict
    :param socket_data: moving object socket link offset. x,y,z and yaw,pitch,roll
    :type socket_data: dict
    :return: moving object formula representation
    :rtype: dict
    """
    # moving object needs to be used.
    # Moving object properties and structure by reverse engineering:
    # {
    #    "obj_type": "movingObject",
    #    "id": "moving_object_001",
    #    "name" :"",
    #    "type": "<brandID>",
    #    "waypoints": [  # Empty list in case the object is a child object
    #      "isAnchor": false,
    #      "movingObjectId": "MO0001",
    #      "position": {
    #        "lat": 12.34,
    #        "lng": 12.34,
    #      }
    #    ],
    #    "scripts": [],
    #    "isEgoCar": false,
    #    "parentObject": Structure as defined by create_moving_object_parent_data()
    # }

    # Make sure either path or parent are filled, but not both
    # Path is for a moving object as usual, parent is for a child moving object, linked using a socket
    assert (path is not None or parent_obj_data is not None) and ((path is None) != (parent_obj_data is None))

    moving_object_id = "moving_object_{:04}".format(this.STATIC_MOVING_OBJECTS_CNT)
    this.STATIC_MOVING_OBJECTS_CNT += 1
    default_scripts = []
    if path is not None:
        for waypoint in path:
            waypoint["movingObjectId"] = moving_object_id

        default_scripts = [
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(0),
                                                    ActorScript.create_set_path_speed_action(speed)),
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(0),
                                                    ActorScript.create_set_path_acceleration_action(acceleration)),
            ActorScript.create_moving_object_script(ActorScript.create_waypoint_trigger(0),
                                                    ActorScript.create_set_orientation_over_path_action(orientation))
        ]
    else:
        if socket_data is None:
            socket_data = {}
        # Child moving object
        default_scripts = [
            ActorScript.create_moving_object_script(__create_implicit_script_trigger(),
                                                    ActorScript.create_set_socket_orientation_action(
                                                        offset_x=socket_data.get("x", 0),
                                                        offset_y=socket_data.get("y", 0),
                                                        offset_z=socket_data.get("z", 0),
                                                        offset_yaw=socket_data.get("yaw", 0),
                                                        offset_pitch=socket_data.get("pitch", 0),
                                                        offset_roll=socket_data.get("roll", 0),
                                                    ))
        ]

    if scripts is None or not isinstance(scripts, list):
        scripts = list()

    for script in default_scripts:
        script["readOnly"] = True
    for script in scripts:
        script["readOnly"] = False

    scripts = default_scripts + scripts
    for script in scripts:
        script["movingObjectId"] = moving_object_id

    moving_object = {
        "id": moving_object_id,
        "name": name,
        "type": type,
        "obj_type": "movingObjects",
        "waypoints": path or [],
        "scripts": scripts,
        "isEgoCar": False  # For now Path driven ego car is not supported
    }
    if parent_obj_data is not None:
        moving_object["parentObject"] = parent_obj_data

    return moving_object


def create_moving_object_parent_data(parent_id, parent_socket_index, parent_socket_name):
    return {
        "parentMovingObjectId": parent_id,
        "socketIndex": parent_socket_index,
        "parentSocketName": parent_socket_name
    }


def create_spawn_area_cars(name, segments, shapes, color, object_count, distribution, use_full_physics,
                           speed, initial_speed, politeness_range, lane_change_speed_range,
                           comfortable_braking, time_to_collision_range, driver_model=None, 
                           despawn_options=None, spawn_repeat=None, attach_to=None):
    
    if despawn_options is None:
        despawn_options = DEFAULT_DESPAWN_OPTIONS


    if spawn_repeat is None:
        spawn_repeat = DEFAULT_SPAWN_REPEAT_OPTIONS

    return __create_spawn_area("cars", name, segments, shapes, color, object_count, distribution,
                               use_full_physics, speed, initial_speed, politeness_range,
                               lane_change_speed_range, comfortable_braking, time_to_collision_range, driver_model, 
                               despawn_options, spawn_repeat, attach_to)


def create_spawn_area_parking(name, segments, shapes, color, object_count, distribution):
    return __create_spawn_area("parking_cars", name, segments, shapes, color, object_count, distribution)


def create_spawn_area_pedestrians(name, segments, shapes, color, object_count, distribution, use_full_physics):
    return __create_spawn_area("people", name, segments, shapes, color, object_count, distribution, use_full_physics)


def __create_spawn_area(spawn_type, name, segments, shapes, color, object_count, distribution,
                        use_full_physics=None, speed=None, initial_speed=None, politeness_range=None,
                        lane_change_speed_range=None, comfortable_braking=None, time_to_collision_range=None,
                        driver_model=None, despawn_options=None, spawn_repeat=None, attach_to=None):

    if driver_model is None:
        driver_model = DEFAULT_DRIVER_MODEL

    spawn_area_type = AttachToOptions.SpawnAreaType.MAP_POSITION.value
    if attach_to is not None:
         spawn_area_type = AttachToOptions.SpawnAreaType.ANCHOR_OBJECT.value

    spawn_object_id = "spawn_object_{:04}".format(this.STATIC_SPAWN_OBJECTS_CNT)
    this.STATIC_SPAWN_OBJECTS_CNT += 1
    spawn_area = {
        "id": spawn_object_id,
        "type": spawn_type,
        "obj_type": "spawn_objects",
        "name": name,
        "segments": segments,
        "shapes": shapes,
        "color": color,
        "object_count": object_count,
        "distribution": distribution,
        "use_full_physics": use_full_physics,
        "speed": speed,
        "initial_speed": initial_speed,
        "politeness": politeness_range,
        "lane_change_speed": lane_change_speed_range,
        "comfortable_braking": comfortable_braking,
        "time_to_collision": time_to_collision_range,
        "driver_model": driver_model,
        "despawn_options": despawn_options,
        "attach_to": attach_to,
        "spawn_area_type": spawn_area_type,
        "spawn_repeat": spawn_repeat
    }
    excess = []
    for k, v in spawn_area.items():
        if v is None:
            excess.append(k)
    for k in excess:
        spawn_area.pop(k)
    return spawn_area


def __create_implicit_script_trigger():
    # Use this function to create trigger for an implicit script.
    # An implicit script is for configuration of objects whose unexposed
    # implementation is in a script. E.g. initial_speed
    # Implicit scripts are all assigned on time 0, to be set on the beginning of the simulation
    return ActorScript.create_simulation_time_trigger(0)


def __create_end_point_action(obj_name):
    return ActorScript.create_set_destination_action(f"{obj_name} end")


def create_driving_behaviour_object(initial_speed=15, desired_speed=15, comfortable_braking=2,
                                    time_to_collision=1.5, distance_to_collision=10,
                                    lane_change_speed=0.25, politeness=20, gear_mode=ActorScript.c_GEAR_MOD_DRIVE):
    driving_behaviour = {
        "politeness": politeness,
        "comfortable_braking": comfortable_braking,
        "time_to_collision": time_to_collision,
        "distance_to_collision": distance_to_collision,
        "lane_change_speed": lane_change_speed,
        "initial_speed": initial_speed,
        "desired_speed": desired_speed,
        "gear_mode": gear_mode
    }
    return driving_behaviour