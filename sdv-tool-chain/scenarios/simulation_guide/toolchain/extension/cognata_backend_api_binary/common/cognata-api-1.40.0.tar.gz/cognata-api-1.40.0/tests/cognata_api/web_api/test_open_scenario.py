import json
import time

import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server


@pytest.fixture
def cognata_api():
    return connect_to_server()


PARAMS = [
    ("test-213", "urban", "valid", ["testTag1"]),
    # ("test-2222", "test", "invalid-stype", ["a"]),
    # ("", "urban", "test-name-empty-string", ["noName"]),
    # ("test-43333", "urban", "tags-none", None)
]


@pytest.mark.parametrize("name,stype,desc,tags", PARAMS)
def test_create_open_scenario_package_object(cognata_api, name, stype, desc, tags):
    cognata_api._create_open_scenario_package_catalog_object(
        name=name,
        scenes_type=stype,
        description=desc,
        tags=tags
    )


@pytest.mark.two
def test_get_open_scenario_package_list(cognata_api):
    packages = cognata_api.get_open_scenario_package_list()
    for p in packages:
        cognata_api.delete_open_scenario_package(p["sku"])
        print(json.dumps(p, indent=2))


@pytest.mark.three
def test_find_open_scenario_package(cognata_api):
    open_scenario_package_obj = cognata_api.find_open_scenario_package("TESTPACK")
    print(json.dumps(open_scenario_package_obj, indent=2))


@pytest.mark.four
def test_delete_open_scenario_package(cognata_api):
    cognata_api.remove_open_scenario_package("TESTOPEN")


def test_create_open_scenario_package(cognata_api):
    zipfile = "test_data/test-openScenario-package.zip"
    res = cognata_api.create_open_scenario_package(
        name="TestPack",
        scenes_type="urban",
        package_zipfile=zipfile,
        description="",
        tags=["TEST2", "TEST3"],
    )
    print(json.dumps(res, indent=2))


def test_update_open_scenario_package_items_list(cognata_api):
    package_sku = "TESTPACK"
    items_list = []
    res = cognata_api._update_open_scenario_package_items_list(package_sku, items_list)
    print(json.dumps(res, indent=2))


def test_get_open_scenario_package_import_status(cognata_api):
    reports = cognata_api.get_open_scenario_package_import_status("TESTOPEN1")
    print(json.dumps(reports, indent=2))


def test_create_test_plan(cognata_api):
    scenarios_sku = ["CUTINSLO9"]
    if not scenarios_sku:
        return

    post_res = cognata_api.create_test_plan(
        name=f"package_nsdsame Test Planq",
        scenarios_sku_list=scenarios_sku
    ).json()
    print(post_res.get("message"))
    return post_res


def monitor_in_progress_hdmap(cognata_api, item_sku):
    """
    monitor_in_progress_hdmap
    """
    while True:
        created_map = cognata_api.find_map(item_sku)
        upload_status = created_map['properties']['uploadStatus']
        if upload_status in ['success', 'failure']:
            return upload_status

        time.sleep(2)
        print(f"monitoring: {upload_status}")


def create_hdmap_catalog_object(cognata_api, hdmap_name):
    try:
        map_data = {
            "name": hdmap_name,
            "description": f"Uploaded with open scenarios files"
        }
        created_map = cognata_api.create_map(
            catalog_data=map_data,
            skeleton=None,
            type="highway"
        )

        return created_map.get("sku")

    except Exception as err:
        print(err)


def import_hdmap_xodr_file(cognata_api, xodr_file, map_sku):
    upload_res = cognata_api.set_map_xodr(map_sku, xodr_file)
    return upload_res


def test_import_hdmap(cognata_api):
    sku = create_hdmap_catalog_object(cognata_api, "TEST11")
    if sku is not None:
        import_hdmap_xodr_file(cognata_api, "test_data/e6mini.xodr", sku)
    else:
        print("FAILED TO GENERATE MAP")