# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import logging
import random
import string

color_to_hex_map ={
    "Red": "#8e1208",
    "Blue": "#0f0fb4",
    "Yellow": "#c0b23e",
    "Purple": "#6e32c5",
    "Magenta": "#e035ff",
    "Brown": "#9b4f04",
    "Orange": "#ff9815",
    "Green": "#329a05",
}


def color_to_hex(color):
    if color not in color_to_hex_map:
        logging.error("Unsupported color sent {color}".format(color=color))
        return
    hex_color = color_to_hex_map[color]
    return hex_color


def range_object(_min, _max):
    return {"min": _min, "max": _max}


def number_to_change_lane_direction(change_lane_direction):
    if change_lane_direction == -1:
        return "Right"
    else:
        return "Left"


def get_id():
    # Generate a random string
    # with 32 characters.
    id = ''.join([random.choice(string.ascii_letters
                                + string.digits) for n in range(32)])
    return id


def create_polygon(positions):
    return {}


def remove_nones_from_dict(d):
    # This function removes None objects recursively from a dictionary
    # Supports:
    # - nested objects
    # - nested lists
    # - list in list
    clean = {}
    if not (isinstance(d, dict) or isinstance(d, list)):
        return d
    if isinstance(d, dict):
        for k, v in d.items():
            if isinstance(v, dict):
                nested = remove_nones_from_dict(v)
                if nested is not None:
                    clean[k] = nested
            elif isinstance(v, list):
                nested_array = []
                for element in v:
                    if isinstance(element, dict) or isinstance(element, list):
                        element = remove_nones_from_dict(element)
                    if element is not None:  # Check not None or empty
                        nested_array.append(element)
                clean[k] = nested_array
            elif v is not None:
                clean[k] = v
    elif isinstance(d, list):
        clean = []
        for elem in d:
            clean.append(remove_nones_from_dict(elem))
    return clean
