from typing import List

import pytest
import random
import time
import os.path as osp
import cognata_api.scenario.ai_vehicle as AiVehicle
import cognata_api.scenario.position as Position
from cognata_api.scenario.scenario import Scenario
from cognata_api.scenario.terrain import Terrain
from tests.cognata_api.web_api.connect_to_host import connect_to_server

@pytest.fixture
def cognata_api():
    return connect_to_server()

DEFAULT_PRIORITY = 10
MIN_PRIORITY = 0
GENERATE_SIMULATION_PARAMS = [
    None,
    0,
    100,
    3,
    -19
]

#Test generate_simulation with running_priority parameter
@pytest.mark.parametrize("running_priority", GENERATE_SIMULATION_PARAMS)
def test_generate_simulation_with_priority(cognata_api, running_priority):
    #  Simulation definition
    test_name = osp.basename(__file__).split(".py")[0]
    test_number = "DRPD-4718"
    description = "Termination by time"

    time = 2

    # map/preset definition
    maps = {x['name']: x['sku'] for x in cognata_api.get_maps_list(lite=True, readOnly=True)}
    terrain = Terrain(maps['Synthetic Single'])
    presets = {x['name']: x['sku'] for x in cognata_api.get_ego_cars_list()}

    # Ego's creation
    ego_position = Position.create_position(lat=41.73166992098592, lng=-116.94809161126615, first_section_id=0,
                                            last_section_id=0,
                                            road_id="0", segment_id="0_0_0_-2")

    ego_behaviour = AiVehicle.create_driving_behaviour_object(initial_speed=0, desired_speed=0)
    ego_car = AiVehicle.create_ego_car_v2(spawn_pos=ego_position, driving_behaviour=ego_behaviour,
                                          sku=presets['Single_Cam'], scripts=[])

    # Simulation creation
    scene = Scenario(name=test_number + ": " + test_name, description=description, terrain=terrain,
                     timeout=time, ego_car=ego_car)

    simulation = cognata_api.generate_simulation(
        scenario_data=scene.get_formula(),
        client_driver_version='',
        cognata_engine_version='',
        annotate=False,
        visibility_report=False,
        driver_mode=None,
        running_priority=running_priority
    )
    scene_id = cognata_api.get_simulation_run_id(simulation)

    print("\n", simulation)
    simulation_runs = cognata_api.find_simulation_runs_queue()

    if running_priority is None:
        assert simulation_runs['data'][0]['priority'] == DEFAULT_PRIORITY
    elif 0 > running_priority:
        assert simulation_runs['data'][0]['priority'] == MIN_PRIORITY
    else:
        assert simulation_runs['data'][0]['priority'] == running_priority



TPEX_PARAMS = [
    10,
    None,
    255,
    -5
]

@pytest.mark.parametrize("running_priority", TPEX_PARAMS)
def test_test_plan_execution_with_priority(cognata_api, running_priority:int):
    test_name = 'running priority for test plan'
    counter = 0

    # Get scenario from existing scenarios and add it to test plan
    sce_list = cognata_api.get_scenarios_list()
    sce = random.choice(sce_list)
    sce_sku = sce['sku']

    # Get all Test plan names to verify name not exist.
    tp_name = [x['name'] for x in cognata_api.get_test_plans_list()]
    while test_name in tp_name:
        test_name = f'test tpex priority_{counter}'
        counter += 1

    # Create test plan.
    response = cognata_api.create_test_plan(name=test_name, scenarios_sku_list=[sce_sku], tags=['Studio sdk test'])
    tps = cognata_api.get_test_plans_list();
    tp_sku = [t['sku'] for t in tps if t['name'] == test_name]

    # Execute test plan
    tp_execute_response = cognata_api.execute_test_plan(
        test_plan_sku=tp_sku[0],
        ego_car_sku='AISUV',
        sensors_preset_sku='SINGLECA',
        car_physics_sku='SUVCARPHYSICS',
        running_priority=running_priority
    )
    time.sleep(1)
    tpexs = cognata_api.get_test_plan_execution_list()
    tpex = next((t for t in tpexs if t['_id'] == tp_execute_response['response']['testPlanExecutionID']), None)

# Check
    if running_priority is None:
        assert tpex['runningPriority'] == DEFAULT_PRIORITY
    elif running_priority < MIN_PRIORITY:
        assert tpex['runningPriority'] == MIN_PRIORITY
    else:
        assert tpex['runningPriority'] == running_priority

    sim_runs_response = cognata_api.get_test_plan_execution_runs(tpex['_id'])
    if sim_runs_response:
        sim_runs = sim_runs_response['data']
    misses = []
    for sim_run in sim_runs:
        if ((running_priority is None or 0 > running_priority) and sim_run['priority'] != DEFAULT_PRIORITY) or sim_run['priority'] != running_priority:
            misses.append(sim_run)

    #assert len(misses) == 0

GET_QUEUE_PARAMS = [
    "priority|desc"
]

@pytest.mark.parametrize("sort", GET_QUEUE_PARAMS)
def test_order_queue_by_priority(cognata_api, sort):
    simulation_runs = cognata_api.find_simulation_runs_queue(
        queue="cloud",
        status=None,
        resolution=None,
        sort=sort,
        limit=None,
        offset=None,
        search_str=None,
        tpex_id=None
    )
    # check if list is ordered by priority
    is_out_of_order = False
    i = 1
    simulation_runs_data = simulation_runs['data']
    print("\n")
    while i < len(simulation_runs_data):
        if 'priority' in simulation_runs_data[i] and 'priority' in simulation_runs_data[i - 1]:
            print(simulation_runs_data[i]['priority'])
            if simulation_runs_data[i]['priority'] > simulation_runs_data[i - 1]['priority']:
                is_out_of_order = True
        i += 1
    assert not is_out_of_order

def test_rerun(cognata_api):
    simulation_runs_result = cognata_api.find_simulation_runs_queue(queue="cloud", limit=300)
    sim_runs = simulation_runs_result['data']
    if len(sim_runs) == 0:
        print('\nNoting to rerun')
        return
    random_sim_run = random.choice(sim_runs)
    random_sim_run_id = random_sim_run['_id']
    new_sim_run_id = cognata_api.rerun_simulation(random_sim_run_id)
    new_simulation_run_data = cognata_api.find_simulation_run(new_sim_run_id)

    random_sim_run_priority = random_sim_run['priority']
    print('\npriority:', random_sim_run_priority)
    if random_sim_run_priority is None:
        assert new_simulation_run_data['priority'] == DEFAULT_PRIORITY
    else:
        assert new_simulation_run_data['priority'] == random_sim_run_priority
