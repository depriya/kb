import json
import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server
from cognata_api.web_api.cognata_demo import (
    CognataRequests, 
    CognataEgoCar, 
    CognataScenario, 
    CognataEngineSettings, 
    CognataSimulationTermination, 
    CognataTerrain, 
    CognataCartesianParams,
    CognataPositionObject,
    CognataDynamicObject,
    CognataSpawnArea
)
import tests.cognata_api.web_api.testing_utils as testing_utils


@pytest.fixture
def cognata_api():
    return connect_to_server()

@pytest.fixture
def ego_car_object():
    return CognataEgoCar(
        ego_car_sku="CAMRADAR1",
        starting_point={"lane": -3, "roadId": "1", "firstSectionID": 1, "lastSectionID": 1,
                        "segmentId": "1_1_1_-3", "lng": 8.67646097254692, "lat": 50.06138430343974},
        ending_point={"lane":- 3, "roadId": "1", "firstSectionID": 4, "lastSectionID": 4,
                        "segmentId": "1_4_4_-4", "lng": 8.669625744745645, "lat": 50.06132920297858},
        initial_speed=15,
        desired_speed=15,
        lane_change_speed=0.25,
        time_to_collision=1.5,
        comfortable_braking=2,
        politeness=20,
        driver_model="STANDARD"
    )

@pytest.fixture
def simulation_termination_conditions():
    return CognataSimulationTermination(timeout=12, distance=500, preventOnCollision=True)

@pytest.fixture
def engine_settings():
    return CognataEngineSettings("High-quality perception oriented")

@pytest.fixture
def terrain_object():
    return CognataTerrain(id="hdm-EU20201842", mode="")

@pytest.fixture
def cartesian_object():
    return CognataCartesianParams(["6789"], time_of_day=["morning"], weather_conditions=["clear"])

def create_scenario(name: str,
                    ego_car_object: CognataEgoCar,
                    simulation_termination: CognataSimulationTermination,
                    engine_settings: CognataEngineSettings,
                    terrain: CognataTerrain,
                    cartesian_object: CognataCartesianParams,
                    spawn_objects: list[CognataSpawnArea],
                    dynamic_objects: list[CognataDynamicObject]):
    return CognataScenario(
        name=name,
        description="Test scenario",
        simulation_termination=simulation_termination,
        cartesian_params=cartesian_object,
        spawn_objects=spawn_objects,
        ego_car=ego_car_object,
        terrain=terrain,
        analysis_rules=[],
        dynamic_objects=dynamic_objects,
        queues=["cloud"],
        engine_settings=engine_settings
    )

PARAMS = [
    (None, None, "all"),
    (None, None, "digestible"),
    (None, "hdm-EU20201842", "digestible"),
    (None, "hdm-EU20201842", "all"),
]

TERMINATION_PARAMS = [
    CognataSimulationTermination(timeout=12, distance=500, preventOnCollision=False),
    CognataSimulationTermination(timeout=30, distance=600, preventOnCollision=True),
    CognataSimulationTermination(timeout=10, distance=300)
]
DRIVER_MODELS = ["RECKLESS", "GRANDMOT", "EASYDRIV", "STANDARD"]

VALID_PHYSICS = "SUVCARPHYSICS"
INVALID_PHYSICS = "INVALID-17"
SCENARIO_PARAMS = [
    ("TEST - BAD PHYSICS DYNAMIC OBJECT", VALID_PHYSICS, INVALID_PHYSICS),
    ("TEST - BAD PHYSICS EGO CAR", INVALID_PHYSICS, VALID_PHYSICS),
    (pytest.param("TEST - VALID PHYSICS", VALID_PHYSICS, VALID_PHYSICS, marks=pytest.mark.xfail)),
    (pytest.param("TEST - NO PHYSICS", None, None, marks=pytest.mark.xfail))
]

@pytest.mark.parametrize("search,hdmap,digestible", PARAMS)
def test_get_scenarios_list(cognata_api, search, hdmap, digestible):
    fetched_scenarios = cognata_api.get_scenarios_list(
        search_str=search,
        map_sku=hdmap,
        digestible=digestible
    )
    print("\n", len(fetched_scenarios))
    for scenario in fetched_scenarios:
        print(json.dumps(scenario, indent=2))

@pytest.mark.parametrize("driver_model", DRIVER_MODELS)
def test_save_scenario_with_ego_car_with_driver(cognata_api: CognataRequests, 
                                                         simulation_termination_conditions: CognataSimulationTermination,
                                                         engine_settings: CognataEngineSettings,
                                                         terrain_object: CognataTerrain,
                                                         cartesian_object: CognataCartesianParams,
                                                         driver_model: str):
    ego_car_object = CognataEgoCar(
        ego_car_sku="CAMRADAR1",
        starting_point={"lane": -3, "roadId": "1", "firstSectionID": 1, "lastSectionID": 1,
                        "segmentId": "1_1_1_-3", "lng": 8.67646097254692, "lat": 50.06138430343974},
        ending_point={"lane":- 3, "roadId": "1", "firstSectionID": 4, "lastSectionID": 4,
                        "segmentId": "1_4_4_-4", "lng": 8.669625744745645, "lat": 50.06132920297858},
        initial_speed=15,
        desired_speed=15,
        lane_change_speed=0.25,
        time_to_collision=1.5,
        comfortable_braking=2,
        politeness=20,
        driver_model=driver_model
    )

    standard_ego_scenario = create_scenario(
        name="EgoCarScenario",
        simulation_termination=simulation_termination_conditions,
        cartesian_object=cartesian_object,
        spawn_objects=[],
        ego_car_object=ego_car_object,
        terrain=terrain_object,
        dynamic_objects=[],
        engine_settings=engine_settings
    )

    saved_scenario = cognata_api.create_scenario(standard_ego_scenario.to_json())
    new_scenario_id = saved_scenario["_id"]
    
    scenario = cognata_api.find_scenario(new_scenario_id)
    assert scenario["ego_car"]["driver_model"] == driver_model

@pytest.mark.parametrize("driver_model", DRIVER_MODELS)
def test_save_scenario_with_dynamic_object_with_driver(cognata_api: CognataRequests, 
                                                                ego_car_object: CognataEgoCar,
                                                                simulation_termination_conditions: CognataSimulationTermination,
                                                                engine_settings: CognataEngineSettings,
                                                                terrain_object: CognataTerrain,
                                                                cartesian_object: CognataCartesianParams,
                                                                driver_model: str):
    dynamic_position_start = CognataPositionObject(
        lane=-3,
        roadId="1",
        firstSectionID=3,
        lastSectionID=3,
        lat=50.061355011569646,
        lng=8.672333304709355
    )
    dynamic_position_end = CognataPositionObject(
        lane=-4,
        roadId="1",
        firstSectionID=3,
        lastSectionID=3,
        lat=50.06134812401125,
        lng=8.67045575839893
    )

    dynamic_object = CognataDynamicObject(
        name="Dynamic object 0001",
        lane=-3,
        type="Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black",
        position={
            "start": dynamic_position_start,
            "end": dynamic_position_end
        },
        scripts={},
        driver_model=driver_model
    )

    standard_ego_scenario = create_scenario(
        name="DynamicObjectScenario",
        simulation_termination=simulation_termination_conditions,
        cartesian_object=cartesian_object,
        spawn_objects=[],
        ego_car_object=ego_car_object,
        terrain=terrain_object,
        dynamic_objects=[dynamic_object],
        engine_settings=engine_settings
    )

    saved_scenario = cognata_api.create_scenario(standard_ego_scenario.to_json())
    new_scenario_id = saved_scenario["_id"]
    
    scenario = cognata_api.find_scenario(new_scenario_id)
    assert scenario["ego_car"]["driver_model"] == "STANDARD"
    assert scenario["dynamic_objects"][0]["driver_model"] == driver_model

@pytest.mark.parametrize("driver_model", DRIVER_MODELS)
def test_save_scenario_with_spawn_area_with_driver(cognata_api: CognataRequests, 
                                                            ego_car_object: CognataEgoCar,
                                                            simulation_termination_conditions: CognataSimulationTermination,
                                                            engine_settings: CognataEngineSettings,
                                                            terrain_object: CognataTerrain,
                                                            cartesian_object: CognataCartesianParams,
                                                            driver_model: str):
    spawn_object = CognataSpawnArea(
        name="Spawn area 0001",
        id="Spawn area 0001",
        end_position={"lane": 3, "sectionId": 2, "fragmentId": 1210},
        start_position={"lane": 3, "sectionId": 2, "fragmentId": 1170},
        comfortable_braking={"max": 2, "min": 2},
        lane_change_speed={"max": 0.25, "min": 0.25},
        politeness={"max": 20, "min": 20},
        initial_speed={"max": 30, "min": 20},
        speed={"max": 30, "min": 20},
        time_to_collision={"max": 1.5, "min": 1.5},
        distribution=[CognataRequests.get_brand(brand_label="Generic Combi Black"),
                    CognataRequests.get_brand(brand_label="Generic SUV White")],
        object_count=2,
        shapes=[],
        driver_model=driver_model
    )

    standard_ego_scenario = create_scenario(
        name="SpawnAreaScenario",
        simulation_termination=simulation_termination_conditions,
        cartesian_object=cartesian_object,
        spawn_objects=[spawn_object],
        ego_car_object=ego_car_object,
        terrain=terrain_object,
        dynamic_objects=[],
        engine_settings=engine_settings
    )

    saved_scenario = cognata_api.create_scenario(standard_ego_scenario.to_json())
    new_scenario_id = saved_scenario["_id"]
    
    scenario = cognata_api.find_scenario(new_scenario_id)
    assert scenario["ego_car"]["driver_model"] == "STANDARD"
    assert scenario["spawn_objects"][0]["driver_model"] == driver_model

def test_save_scenario_with_ego_car_with_invalid_driver(cognata_api: CognataRequests, 
                                                         simulation_termination_conditions: CognataSimulationTermination,
                                                         engine_settings: CognataEngineSettings,
                                                         terrain_object: CognataTerrain,
                                                         cartesian_object: CognataCartesianParams):
    ego_car_object = CognataEgoCar(
        ego_car_sku="CAMRADAR1",
        starting_point={"lane": -3, "roadId": "1", "firstSectionID": 1, "lastSectionID": 1,
                        "segmentId": "1_1_1_-3", "lng": 8.67646097254692, "lat": 50.06138430343974},
        ending_point={"lane":- 3, "roadId": "1", "firstSectionID": 4, "lastSectionID": 4,
                        "segmentId": "1_4_4_-4", "lng": 8.669625744745645, "lat": 50.06132920297858},
        initial_speed=15,
        desired_speed=15,
        lane_change_speed=0.25,
        time_to_collision=1.5,
        comfortable_braking=2,
        politeness=20,
        driver_model="INVALID"
    )

    standard_ego_scenario = create_scenario(
        name="EgoCarScenario",
        simulation_termination=simulation_termination_conditions,
        cartesian_object=cartesian_object,
        spawn_objects=[],
        ego_car_object=ego_car_object,
        terrain=terrain_object,
        dynamic_objects=[],
        engine_settings=engine_settings
    )

    try:
        cognata_api.create_scenario(standard_ego_scenario.to_json())
    except RuntimeError as error:
        errorMessage = str(error).replace("'", '"')
        assert "Unsupported driver model on ego car" in errorMessage

@pytest.mark.parametrize("simulation_termination_conditions", TERMINATION_PARAMS)
def test_save_scenario_with_prevent_collision_termination_false(ego_car_object: CognataEgoCar,
                                                               cognata_api: CognataRequests, 
                                                               engine_settings: CognataEngineSettings,
                                                               terrain_object: CognataTerrain,
                                                               cartesian_object: CognataCartesianParams,
                                                               simulation_termination_conditions: CognataSimulationTermination):
    standard_ego_scenario = create_scenario(
        name="TerminationOnCollisionFalse",
        simulation_termination=simulation_termination_conditions,
        cartesian_object=cartesian_object,
        spawn_objects=[],
        ego_car_object=ego_car_object,
        terrain=terrain_object,
        dynamic_objects=[],
        engine_settings=engine_settings
    )
    saved_scenario = cognata_api.create_scenario(standard_ego_scenario.to_json())
    new_scenario_id = saved_scenario["_id"]
    scenario = cognata_api.find_scenario(new_scenario_id)
    expected_termination_conditions = simulation_termination_conditions.to_json()
    assert scenario["simulation_termination"]["preventOnCollision"] == expected_termination_conditions["preventOnCollision"]
    assert scenario["simulation_termination"]["timeout"] == expected_termination_conditions["timeout"]
    assert scenario["simulation_termination"]["distance"] == expected_termination_conditions["distance"]


@pytest.mark.parametrize("name, physics_ego, physics_dynamic", SCENARIO_PARAMS)
def test_save_scenario(cognata_api, name, physics_ego, physics_dynamic):
    # ALSO TESTS GENERATE SIMULATION
    ego = testing_utils.get_simple_ego_car(car_physics_sku=physics_ego)
    dynamic = testing_utils.get_simple_dynamic_object(car_physics_sku=physics_dynamic)
    scenario = testing_utils.get_simple_scenario_object(name=name, ego_car=ego)
    spawn_area = testing_utils.get_simple_spawn_area_cars()
    scenario.add_dynamic_object(dynamic)
    scenario.add_spawn_object(spawn_area)
    formula = scenario.get_formula()
    cognata_api.create_scenario(formula)
    cognata_api.generate_simulation(formula)

