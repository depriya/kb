import warnings
warnings.warn("cognata_demo is deprecated, use cognata_api_wrapper instead", DeprecationWarning)
from .cognata_api_wrapper import *