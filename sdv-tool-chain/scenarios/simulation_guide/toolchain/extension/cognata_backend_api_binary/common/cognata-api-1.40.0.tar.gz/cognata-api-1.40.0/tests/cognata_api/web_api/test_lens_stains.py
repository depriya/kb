from typing import List

import pytest
import time
import random
from tests.cognata_api.web_api.connect_to_host import connect_to_server
import cognata_api.web_api.cognata_api_wrapper as sdk


api = connect_to_server()


@pytest.fixture
def cognata_api():
    return connect_to_server()


def _get_random_lens_stains_sku(read_only=None):
    lens_stains_list = api.get_lens_stains_list(read_only=read_only)
    rnd_lens_stains = lens_stains_list[random.randint(0, len(lens_stains_list) - 1)]
    return rnd_lens_stains["sku"]


# Params Definition
CREATE_LENS_STAINS_PARAMS = [
    "../../../../studio/infrastructure/build_db/assetsFiles/catalogFiles/sensorFiles/lensStains/ls_dirt_particles.json",
    pytest.param("", marks=pytest.mark.xfail)
]
DELETE_LENS_STAINS_PARAMS = [
    _get_random_lens_stains_sku(read_only=False),
    _get_random_lens_stains_sku(read_only=True),
    "NON_EXISTING"
]
GET_LENS_STAINS_PARAMS = [
    "NON_EXISTING",
    pytest.param("NON_EXISTING", marks=pytest.mark.xfail)
]
CREATE_SENSOR_PRESET_PARAMS = [
    (None, None, None, None, None, None, None, None),
    (_get_random_lens_stains_sku(), 0, 0, True, 1, 1, 0.2, True),
    (_get_random_lens_stains_sku(), -3, None, None, None, None, None, None), # horizontal_offset out of range
    (_get_random_lens_stains_sku(), None, -1, None, None, None, None, None),  # vertical_offset out of range
    (_get_random_lens_stains_sku(), None, None, False, 0, None, None, None),  # horizontal_scale out of range
    (_get_random_lens_stains_sku(), None, None, None, None, 0, None, None),  # vertical_scale out of range
    (_get_random_lens_stains_sku(), None, None, None, None, 0, None, False),  # rotation out of range
    pytest.param("NON_EXISTING", None, None, None, None, None, None, None, marks=pytest.mark.xfail)
]


@pytest.mark.parametrize("file_path", CREATE_LENS_STAINS_PARAMS)
def test_lens_stains_creation(cognata_api, file_path):
    try:
        # Valid lens stains creation
        name = f"Lens_Stains_{time.time()}"
        texture_file_path = file_path
        lens_stains = cognata_api.create_lens_stains(name, name, texture_file_path)
        assert lens_stains is not None
        sku = lens_stains.get("catalogData").get("sku")
        assert sku is not None
        file_name = lens_stains.get("properties").get("files").get("lensStainsTexture")
        assert file_name is not None
    except Exception as error:
        print(f"Unexpected {error}, {type(error)}")


@pytest.mark.parametrize("lens_stains_sku", DELETE_LENS_STAINS_PARAMS)
def test_lens_stains_deletion(cognata_api, lens_stains_sku):
    try:
        deleted = cognata_api.delete_lens_stains(lens_stains_sku)
        assert deleted.get("error") is None
    except Exception as error:
        print(f"Unexpected {error}, {type(error)}")


@pytest.mark.parametrize("lens_stains_sku", GET_LENS_STAINS_PARAMS)
def test_get_lens_stains_obj(cognata_api, lens_stains_sku):
    try:
        lens_stains = cognata_api.get_lens_stains(lens_stains_sku)
        assert len(lens_stains) > 0
    except Exception as error:
        print(error)


@pytest.mark.parametrize("lens_stains_model, horizontal_offset, vertical_offset, auto_scaling,"
                         "horizontal_scale, vertical_scale, rotation, use_in_features", CREATE_SENSOR_PRESET_PARAMS)
def test_sensor_preset_creation(cognata_api, lens_stains_model, horizontal_offset, vertical_offset, auto_scaling,
                                horizontal_scale, vertical_scale, rotation, use_in_features):
    preset = []
    # Create base sensors preset
    gps = sdk.CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
                            sensor_record={"gps": True},
                            sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                            sensor_position={"x": 0, "z": 1.7, "y": 0})
    preset.append(gps.get_sensor_for_preset())
    plain_color_cam = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGCAM", sensor_name="basic_color_cam",
                                        sensor_record={"color": True},
                                        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                        sensor_position={"x": 0, "y": 1.8, "z": 0},
                                        fullscreen={"color": False},
                                        output_format={"color": "JPG"},
                                        bit_depth={"color": "UINT8"},
                                        color_filter={"color": "RGB"})
    preset_cam = plain_color_cam.get_sensor_for_preset()
    sensor_data = preset_cam.get("sensor_data")
    if lens_stains_model is not None:
        sensor_data["lensStains"] = lens_stains_model
    if horizontal_offset is not None:
        sensor_data["stainsHorizontalOffset"] = horizontal_offset
    if vertical_offset is not None:
        sensor_data["stainsVerticalOffset"] = vertical_offset
    if auto_scaling is not None:
        sensor_data["stainsAutoScaling"] = auto_scaling
    if horizontal_scale is not None:
        sensor_data["stainsHorizontalScale"] = horizontal_scale
    if vertical_scale is not None:
        sensor_data["stainsVerticalScale"] = vertical_scale
    if rotation is not None:
        sensor_data["stainsRotation"] = rotation
    if use_in_features is not None:
        sensor_data["stainsOpacityThreshold"] = use_in_features
    preset.append(preset_cam)
    preset_name = f"lens_stains_test_{time.time()}"
    res = cognata_api.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV", sensors=preset)
    assert res["sku"] is not None