from typing import List

import pytest
import time
import json
from tests.cognata_api.web_api.connect_to_host import connect_to_server
import cognata_api.web_api.cognata_api_wrapper as sdk


@pytest.fixture
def cognata_api():
    return connect_to_server()


def test_orthographic_camera(cognata_api):
    preset = []

    gps = sdk.CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
                            sensor_record={"gps": True},
                            sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                            sensor_position={"x": 0, "z": 1.7, "y": 0})
    preset.append(gps.get_sensor_for_preset())

    orthographic_color_cam = sdk.CognataSensor(sensor_type="camera", sensor_sku="COGNATAORTHOGRAPHIC", sensor_name="orthographic_color_cam",
                                        sensor_record={"color": True},
                                        sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                        sensor_position={"x": 0, "y": 0.5, "z": 1.7},
                                        fullscreen={"color": False},
                                        output_format={"color": "JPG"},
                                        bit_depth={"color": "UINT8"},
                                        color_filter={"color": "RGB"})
    preset.append(orthographic_color_cam.get_sensor_for_preset())

    orthographic_thermal_cam = sdk.CognataSensor(sensor_type="camera", sensor_sku="THERMALORTHOGRAPHIC", sensor_name=f"orthographic_thermal_cam",
                                    sensor_record={"heatMap": True},
                                    sensor_rotation={"yaw": 0, "pitch": 0, "roll": 0},
                                    sensor_position={"x": 0, "y": 0.5, "z": 1.7},
                                    fullscreen={"heatMap": False})
    preset.append(orthographic_thermal_cam.get_sensor_for_preset())


    print(json.dumps(preset, sort_keys=True, indent=4))
    preset_name = f"SDK-orthographic_test_{time.time()}"
    res = cognata_api.create_sensors_preset(preset_name=preset_name, ai_car_type="AISUV", sensors=preset)
    print(json.dumps(res, indent=4))
    assert not (hasattr(res, "message") and hasattr(res, "stack"))