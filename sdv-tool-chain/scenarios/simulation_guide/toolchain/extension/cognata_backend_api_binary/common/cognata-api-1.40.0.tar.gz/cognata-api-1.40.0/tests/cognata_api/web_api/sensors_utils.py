from typing import List

import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server
from cognata_api.web_api.cognata_api_wrapper import CognataSensor


api = connect_to_server()


def get_camera(color=True, heatMap=None, thermal_quality='Standard', bb=None, classeg=None, depth=None, pr=None,
               of=None, tpv_cam=None, camera_model=None, of_speed_factor=None,
               lanelineseg=None, high_quality=False, position=None, rotation=None):
    """
    returns basic single cam, FisheyeCam/NarrowCam/WideCam/ParametricFisheye
    change parameters to add features.

    @param tpv_cam: returns third person view cam instead
    @param rgb: record / no record
    @param bb: record / no record
    @param classeg: record / no record
    @param depth: record / no record
    @param pr: record / no record
    @param of: record / no record
    @param lanelineseg: record / no record
    @param camera_model:
    @param rotation: Set rotation
    @param position: Set position
    @param high_quality:
    @param heatMap: Thermal camera record / no record
    @param thermal_quality: Standard (8) , High (14)
    """

    if position is None:
        position = {"x": 0.5, "z": 1.8, "y": 0.01}
    if rotation is None:
        rotation = {"roll": 0, "yaw": 0, "pitch": 0}
    res = get_camera_list()
    cam_models = {cam['name']: cam['sku'] for cam in res}

    if tpv_cam:
        rotation = {"roll": 0, "yaw": 0, "pitch": 15}
        position = {"x": -20, "z": 6, "y": 0.01}

    if camera_model is None:
        camera_model = 'CognataCamera'

    res = get_camera_list()
    cam_models = {cam['name']: cam['sku'] for cam in res}
    camera_model1 = camera_model.replace(' ', '')
    # Build record dict
    sensor_record = {"color": color,
                     "heatMap": heatMap,
                     "bounding_box": bb,
                     "semantic_segmentation": classeg,
                     "lane_line_segmentation": lanelineseg,
                     "depth_map": depth,
                     "photo_realism": pr,
                     "opticalFlow": of}
    delete_keys = []
    for key in sensor_record:
        if sensor_record[key] is None:
            delete_keys.append(key)
    for key in delete_keys:
        del sensor_record[key]

    camera = CognataSensor(sensor_type="camera",
                           sensor_sku=cam_models[camera_model],
                           sensor_name=camera_model1,
                           sensor_record=sensor_record,
                           sensor_rotation=rotation,
                           sensor_position=position,
                           speedFactor={"opticalFlow": of_speed_factor})

    camera_data = camera.get_sensor_for_preset()
    if high_quality:
        camera_data['outputQuality'] = {
            "rgb": "High",
            "depth_map": "High"
        }

        camera_data = camera.get_sensor_for_preset()
        if high_quality:
            camera_data['outputQuality'] = {
                "heatMap": thermal_quality
            }

    return camera_data


def get_camera_list():
    return api.get_sensor(sensor_type="camera", sensor_sku="")


def get_gps():
    gps = CognataSensor(sensor_type="gps", sensor_sku="COGGPS", sensor_name="myGPS",
                            sensor_record={"gps": True},
                            sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                            sensor_position={"x": 0, "z": 1.7, "y": 0})
    return gps.get_sensor_for_preset()
