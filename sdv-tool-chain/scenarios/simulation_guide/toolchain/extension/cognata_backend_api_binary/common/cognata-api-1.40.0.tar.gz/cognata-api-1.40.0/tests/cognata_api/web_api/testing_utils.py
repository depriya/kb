from cognata_api.scenario import ai_vehicle
from cognata_api.scenario import position
from cognata_api.scenario.ai_vehicle import create_spawn_area_cars
from cognata_api.scenario.scenario import Scenario
from cognata_api.scenario.terrain import Terrain
from cognata_api.utils.utils import color_to_hex, range_object

DEFAULT_POSITION = position.create_position(lat=1, lng=1, lane=0)
DEFAULT_SENSOR_PRESET_SKU = "SINGLECA"
DEFAULT_MAP_SKU = "hdm-SY10201842"


def get_simple_ego_car(spawn_pos=None, sku=None, driving_behaviour=None, dest_pos=None,
                       scripts=None, relative_position_obj=None,
                       end_simulation_at_dest=True, car_physics_sku=None):
    spawn_pos = spawn_pos or DEFAULT_POSITION
    sku = sku or DEFAULT_SENSOR_PRESET_SKU

    return ai_vehicle.create_ego_car_v2(
        spawn_pos=spawn_pos,
        sku=sku,
        driving_behaviour=driving_behaviour,
        dest_pos=dest_pos,
        scripts=scripts,
        relative_position_obj=relative_position_obj,
        end_simulation_at_dest=end_simulation_at_dest,
        car_physics_sku=car_physics_sku
    )


def get_simple_dynamic_object(spawn_pos=None, dest_pos=None, is_pos_relative_obj=None,
                              scripts=None, type="Vehicles/Cars/Generic_SUV/Prefabs/Generic_SUV_White",
                              driving_behaviour=None, icon="sedan", name=None, car_physics_sku=None):
    # Set default values for testing
    spawn_pos = spawn_pos or DEFAULT_POSITION
    dest_pos = dest_pos or DEFAULT_POSITION

    return ai_vehicle.create_dynamic_car_v2(
        spawn_pos=spawn_pos,
        dest_pos=dest_pos,
        is_pos_relative_obj=is_pos_relative_obj,
        scripts=scripts,
        type=type,
        driving_behaviour=driving_behaviour,
        icon=icon,
        name=name,
        car_physics_sku=car_physics_sku
    )


def get_simple_spawn_area_cars(driver_model=None):
    segments = [
        position.create_position(lane=-2, road_id="2", first_section_id=19, last_section_id=19,
                                 segment_id="2_19_19_-2"),
        position.create_position(lane=-4, road_id="2", first_section_id=19, last_section_id=19,
                                 segment_id="2_19_19_-4"),
        position.create_position(lane=-3, road_id="2", first_section_id=19, last_section_id=19,
                                 segment_id="2_19_19_-3"),
        position.create_position(lane=-1, road_id="2", first_section_id=19, last_section_id=19, segment_id="2_19_19_-1")
    ]
    return create_spawn_area_cars(name="Spawn area 0003",
                                  segments=segments,
                                  shapes=[],
                                  color=color_to_hex("Yellow"),
                                  object_count=10,
                                  distribution=[
                                      {
                                          "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Blue",
                                          "label": "Car-Generic Pickup Blue"
                                      }
                                  ],
                                  use_full_physics=True,
                                  speed=range_object(20, 30),
                                  initial_speed=range_object(20, 30),
                                  politeness_range=range_object(20, 20),
                                  lane_change_speed_range=range_object(0.25, 0.25),
                                  comfortable_braking=range_object(2, 2),
                                  time_to_collision_range=range_object(1.5, 1.5),
                                  driver_model=driver_model)


def get_simple_scenario_object(name=None, description=None, terrain=None, ego_car=None,
                               timeout=20, use_tight_bounding_box=False):
    name = name or "CREATED WITH get_simple_scenario_object()"
    description = description or "CREATED WITH get_simple_scenario_object()"
    # Synthetic Single as default map
    terrain = terrain or Terrain(DEFAULT_MAP_SKU)
    ego_car = ego_car or get_simple_ego_car()

    scenario_obj = Scenario(
        name=name,
        description=description,
        terrain=terrain,
        ego_car=ego_car,
        timeout=timeout,
        use_tight_bounding_box=use_tight_bounding_box
    )

    return scenario_obj

