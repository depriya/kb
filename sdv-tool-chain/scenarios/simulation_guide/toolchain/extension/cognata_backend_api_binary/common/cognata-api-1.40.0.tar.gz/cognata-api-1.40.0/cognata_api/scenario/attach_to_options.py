from enum import Enum

class SpawnAreaType(Enum):
    MAP_POSITION = 1
    ANCHOR_OBJECT = 2