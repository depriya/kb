# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from enum import Enum


static_cnt = 1


class VariableBase(object):
    class VariableTypes(Enum):
        list = 1
        range = 2
        computed = 3

    class DataTypes(Enum):
        integer = 1
        float = 2
        mapConstant = 3

    def __init__(self, name, data_type, variable_type, values):
        global static_cnt
        self.name = name
        self.id = "var_{}".format(static_cnt)
        static_cnt += 1
        self.var_type = variable_type.value
        self.data_type = data_type.name
        self.fields = []
        if not isinstance(values, list):
            values = [values]
        self.values = values

    def bind_field(self, path, offset, factor):
        self.fields.append({"field_path": path, "factor": factor, "offset": offset})

    @staticmethod
    def get_var_expression(var_name, offset=0.0, factor=1.0):
        return "${{{fac}*{var}+{off}}}".format(fac=factor, var=var_name, off=offset)

    @staticmethod
    def get_var_field_from_expression(var_expression):
        asterisk_idx = var_expression.find("*")
        plus_idx = var_expression.find("+")
        return {"name": var_expression[asterisk_idx+1:plus_idx],
                "factor": float(var_expression[2:asterisk_idx]),
                "offset": float(var_expression[plus_idx+1:-1])}

    def to_json_base(self):
        return {"name": self.name,
                "data_type": self.data_type,
                "variableType": self.var_type,
                "id": self.id,
                "fields": self.fields,
                "values": self.values}


class ComputedVariable(VariableBase):
    def __init__(self, name, data_type, computation_formula):
        super(ComputedVariable, self).__init__(name, data_type, self.VariableTypes.computed, [0])
        self.computation_formula = computation_formula

    def to_json(self):
        base_result = super(ComputedVariable, self).to_json_base()
        base_result.update({"computation_formula": self.computation_formula})
        return base_result


class Variable(VariableBase):
    def __init__(self, name, data_type, values):
        super(Variable, self).__init__(name, data_type, self.VariableTypes.list, values)

    def to_json(self):
        base_result = super(Variable, self).to_json_base()
        return base_result

