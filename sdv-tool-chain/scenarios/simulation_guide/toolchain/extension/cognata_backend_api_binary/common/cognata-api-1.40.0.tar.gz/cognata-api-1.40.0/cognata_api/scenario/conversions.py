# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
def kph_2_ms(number):
    return make_2_decimal(number / 3.6)


def make_2_decimal(number):
    return float("{:.2f}".format(number))


def g_2_ms(speed):
    return speed * 9.8
