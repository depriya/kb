import json
import pytest
from tests.cognata_api.web_api.connect_to_host import connect_to_server


@pytest.fixture
def cognata_api():
    return connect_to_server()


PARAMS = [
    ("TESTNAME", ["SKU1", "SKU2"], ["TAG"], "OPSKU"),
]


@pytest.mark.parametrize("name,scenarios,tags,open_scenario_package_sku", PARAMS)
def test_create_test_plan(cognata_api, name, scenarios, tags, open_scenario_package_sku):
    tp_body = cognata_api.create_test_plan(
        name=name,
        scenarios_sku_list=scenarios,
        tags=tags,
        open_scenario_package_sku=open_scenario_package_sku
    )
    print(json.dumps(tp_body, indent=2))


def test_get_test_plans_list(cognata_api):
    test_plans = cognata_api.get_test_plans_list()
    print(test_plans)
