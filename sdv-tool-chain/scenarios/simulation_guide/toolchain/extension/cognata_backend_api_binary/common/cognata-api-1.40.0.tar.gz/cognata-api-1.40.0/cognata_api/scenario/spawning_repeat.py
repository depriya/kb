from enum import Enum

class RepeatOptions(Enum):
    SINGLE = 0
    CONTINUOUS = 1

class SpawnLocation(Enum):
    ANY = 0
    PERIMETER = 1