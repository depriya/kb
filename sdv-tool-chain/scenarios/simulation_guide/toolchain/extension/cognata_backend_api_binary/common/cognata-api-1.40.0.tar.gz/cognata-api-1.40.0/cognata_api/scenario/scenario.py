# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from typing import List
import logging

from cognata_api.scenario.dynamic_analysis_rule import DynamicAnalysisRule
from cognata_api.scenario.variable import Variable
from cognata_api.utils import utils

CARTESIAN_PARAM_SEED_KEY = "seed"
CARTESIAN_PARAM_WEATHER_KEY = "weather_conditions"
CARTESIAN_PARAM_TIME_OF_DAY_KEY = "time_of_day"
CARTESIAN_PARAM_SYNTHETIC_MAP_VARIANT_KEY = "synthetic_map_variant"
CARTESIAN_PARAM_CONDITION_KEY = "terrain_conditions"
CARTESIAN_PARAM_ROAD_MARKINGS = "road_markings"
CARTESIAN_PARAM_VARIABLES_KEY = "variables"
CARTESIAN_PARAM_TEMPERATURE_KEY = "temperature"


class Scenario:
    __dynamic_analysis_rules: List[DynamicAnalysisRule]

    def __init__(self, name, description, terrain, ego_car, timeout=20, use_tight_bounding_box=False):
        self.__analysis_rules = []
        self.__cartesian_params = {}
        self.__description = description
        self.__dynamic_analysis_rules = []
        self.__dynamic_objects = []
        self.__moving_objects = []
        self.__ego_car = ego_car
        self.__name = name
        self.__simulation_termination = {"distance": -1, "timeout": timeout}
        self._set_tight_bounding_box_mode(use_tight_bounding_box)
        self.__spawn_objects = []
        self.__terrain = terrain
        self.__variables = []
        self.__messages = []
        self.__anchors = []  # User-custom anchors

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, val):
        self.__name = val

    def add_dynamic_analysis_rule(self, dar_obj):
        self.__dynamic_analysis_rules.append(dar_obj)

    def add_dynamic_object(self, dyn_obj):
        self.__dynamic_objects.append(dyn_obj)

    def add_spawn_object(self, spawn_object):
        self.__spawn_objects.append(spawn_object)

    def add_moving_object(self,moving_obj):
        self.__moving_objects.append(moving_obj)
    
    def add_cartesian_param(self, param_name, values_list):
        if param_name not in self.__cartesian_params:
            self.__cartesian_params[param_name] = []
        if not isinstance(values_list, list):
            values_list = [values_list]
        self.__cartesian_params[param_name].extend(values_list)

    def add_variable(self, var):
        self.__variables.append(var)
        self.add_cartesian_param(CARTESIAN_PARAM_VARIABLES_KEY, [
            {"values_list": var.values,
             "variable_id": var.id,
             "name": var.name}
        ])

    def add_event(self, event_id):
        if event_id not in self.__messages:
            self.__messages.append(event_id)

    def add_anchor(self, anchor):
        if anchor not in self.__anchors:
            self.__anchors.append(anchor)

    def set_rules(self, rules):
        self.__analysis_rules = rules

    def add_rule(self, rule):
        self.__analysis_rules.append(rule)

    @staticmethod
    def _convert_rule_id_to_sku(analysis_rules):
        if isinstance(analysis_rules, list):
            for rule in analysis_rules:
                if "RuleID" in rule:
                    rule["Sku"] = rule["RuleID"]
                    rule.pop("RuleID")
        else:
            logging.error("Tried to perform iterative action on non-list object: {}".format(analysis_rules))

        return analysis_rules

    @classmethod
    def _verify_id_field_in_lists(cls, json_object, list_name="list", field_path=""):
        if isinstance(json_object, list):
            # rules_as_formula = copy.deepcopy(rules_list)
            for i in range(len(json_object)):
                if not isinstance(json_object[i], dict):
                    continue
                element_id = None
                if list_name == "scripts":
                    if field_path.startswith("ego_car"):
                        # Set scripts list ids in a format that is required by studio
                        list_name = "ego_car_script"
                    else:
                        element_id = str(i)
                if "id" not in json_object[i]:
                    json_object[i]["id"] = element_id or "{}_{}".format(list_name, i)
                json_object[i] = cls._verify_id_field_in_lists(json_object[i], list_name, field_path)
        else:
            if isinstance(json_object, dict):
                for key in json_object:
                    json_object[key] = cls._verify_id_field_in_lists(json_object[key], key, "{path}{deli}{key}".format(
                        path=field_path, deli='.' if field_path else '', key=key))

        return json_object

    def unwrap_variable_expression(self, val, path):
        field = Variable.get_var_field_from_expression(val)
        found = False
        value_to_put = None
        for var in self.__variables:
            if var.name == field["name"]:
                var.fields.append({"offset": field["offset"],
                                   "factor": field["factor"],
                                   "field_path": ".".join(path)})
                if var.data_type in [Variable.DataTypes.integer.name, Variable.DataTypes.float.name, Variable.DataTypes.mapConstant.name]:
                    # var is of numeric (int/float) type. Put numeric value in val
                    found = True
                    value_to_put = 0
                else:
                    logging.error("Found variable of unsupported data type: {}".format(var.data_type))
                break

        if not found:
            logging.error("Failed to find var named {var_name}, which needs to be replaced in {path}".format(
                var_name=field["name"], path=".".join(path)))
        return found, value_to_put

    def recursively_unwrap_variables(self, curr_obj, path=None):
        if not path:
            path = []
        if isinstance(curr_obj, dict):
            for key in curr_obj:
                path.append(key)
                val = curr_obj[key]
                if isinstance(val, str):
                    if val.startswith("$"):
                        success, new_value = self.unwrap_variable_expression(val, path)
                        if success and new_value is not None:
                            curr_obj[key] = new_value
                else:
                    self.recursively_unwrap_variables(val, path)
                path.pop()
        else:
            if isinstance(curr_obj, list):
                for i in range(len(curr_obj)):
                    # object needs to have id field
                    if isinstance(curr_obj[i], dict) and "id" in curr_obj[i]:
                        id_field = curr_obj[i]["id"]
                        if id_field.isdigit():
                            # For cases where the id is only the index, don't append id__{}
                            path.append(id_field)
                        else:
                            path.append("id__{}".format(id_field))
                        self.recursively_unwrap_variables(curr_obj[i], path)
                        path.pop()

    def unwrap_variables(self, scenario_formula):
        self._verify_id_field_in_lists(scenario_formula)
        self.recursively_unwrap_variables(scenario_formula)

    def get_formula(self):
        # create json
        rv = {
            "analysis_rules": self._convert_rule_id_to_sku(self.__analysis_rules),
            "description": self.__description,
            "dynamic_analysis_rules": [dar.to_json() for dar in self.__dynamic_analysis_rules],
            "dynamic_objects": self.__dynamic_objects,
            "ego_car": self.__ego_car,
            "movingObjects": self.__moving_objects,
            "name": self.__name,
            "simulation_termination": self.__simulation_termination,
            "spawn_objects": self.__spawn_objects,
            "terrain": self.__terrain.to_json(),
            "useVehiclesTightBoundingBoxes": bool(self.__use_tight_bounding_box)
        }

        if CARTESIAN_PARAM_WEATHER_KEY not in self.__cartesian_params:
            self.add_weather_condition("clear")
        if CARTESIAN_PARAM_TIME_OF_DAY_KEY not in self.__cartesian_params:
            self.add_time_of_day("morning")
        if CARTESIAN_PARAM_SEED_KEY not in self.__cartesian_params:
            self.add_random_seed("6789")
        if CARTESIAN_PARAM_CONDITION_KEY not in self.__cartesian_params:
            self.add_terrain_condition("Dry")
        if CARTESIAN_PARAM_ROAD_MARKINGS not in self.__cartesian_params:
            self.add_road_marks_degradation("No wear")
        if CARTESIAN_PARAM_VARIABLES_KEY not in self.__cartesian_params:
            self.add_cartesian_param(CARTESIAN_PARAM_VARIABLES_KEY, [])
        if CARTESIAN_PARAM_TEMPERATURE_KEY not in self.__cartesian_params:
            self.add_temperature(25)
        rv["cartesian_params"] = self.__cartesian_params

        self.__get_all_events()
        if len(self.__messages) > 0:
            rv["scenarioMessages"] = self.__messages
        if len(self.__anchors) > 0:
            rv["userCustomAnchors"] = self.__anchors
        # identify variables usage and add to self.__variables fields accordingly
        self.unwrap_variables(rv)

        json_vars = [var.to_json() for var in self.__variables]

        rv["variables"] = json_vars
        # Remove all None fields from formula
        rv = utils.remove_nones_from_dict(rv)
        # return in formula
        return rv

    def add_random_seed(self, seed):
        self.add_cartesian_param(CARTESIAN_PARAM_SEED_KEY, seed)

    def add_weather_condition(self, weather_condition):
        self.add_cartesian_param(CARTESIAN_PARAM_WEATHER_KEY, weather_condition)

    def add_time_of_day(self, time_of_day):
        self.add_cartesian_param(CARTESIAN_PARAM_TIME_OF_DAY_KEY, time_of_day)

    def add_terrain_condition(self, terrain_condition):
        self.add_cartesian_param(CARTESIAN_PARAM_CONDITION_KEY, terrain_condition)

    def add_road_marks_degradation(self, degradation_level):
        self.add_cartesian_param(CARTESIAN_PARAM_ROAD_MARKINGS, degradation_level)

    def set_map_variants_variable_value_pairs(self, variables_vals_by_map_variants_dict):
        final_map_variants = []
        for map_variant in variables_vals_by_map_variants_dict.keys():
            var_val_pairs = variables_vals_by_map_variants_dict[map_variant]
            vars_list = []
            for var_name, val in var_val_pairs.items():
                vars_list.append({var_name: val})
            final_map_variants.append({"name": map_variant, "variables": vars_list})
        self.add_cartesian_param(CARTESIAN_PARAM_SYNTHETIC_MAP_VARIANT_KEY, [final_map_variants])

    def _set_tight_bounding_box_mode(self, mode):
        """
        Setting the scenario's tight bounding boxes mode
        :param mode: True for enabled/on, False for disabled/off
        :type mode: Boolean
        :return: None
        """
        self.__use_tight_bounding_box = mode

    def enable_tight_bounding_box(self):
        self._set_tight_bounding_box_mode(True)

    def disable_tight_bounding_box(self):
        self._set_tight_bounding_box_mode(False)

    def __get_all_events(self):
        # Iterate over all the scripts and find InvokeEvent actions or EventTrigger triggers.
        # Gather a unique list of all available events and assign to __messages
        # Events are defined by either of the following:
        #   "triggerType": "eventTrigger"
        #   "listenToMessage": "<EventID>"
        # or
        #   "actionType": "invokeEvent"
        #   "actionValue": "<EventID>"
        # TODO: Consider warning about events being triggered and not listened, and the opposite

        # aggregate all scripts in scenario
        all_scripts = list(self.__ego_car.get("scripts", []))
        for dyn in self.__dynamic_objects:
            all_scripts += dyn.get("scripts", [])

        for mo in self.__moving_objects:
            all_scripts += mo.get("scripts", [])

        # iterate over scripts and push event-related scripts
        for sc in all_scripts:
            if "triggerType" in sc and sc["triggerType"] == "eventTrigger" and sc.get("listenToMessage", ""):
                event_id = sc["listenToMessage"]
                self.add_event(event_id)
            if "actionType" in sc and sc["actionType"] == "invokeEvent" and sc.get("actionValue", ""):
                event_id = sc["actionValue"]
                self.add_event(event_id)

    def add_temperature(self, temperature_value):
        self.add_cartesian_param(CARTESIAN_PARAM_TEMPERATURE_KEY, temperature_value)
