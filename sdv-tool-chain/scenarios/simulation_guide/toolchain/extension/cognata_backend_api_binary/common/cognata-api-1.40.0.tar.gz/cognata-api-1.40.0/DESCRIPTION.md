# Cognata Web API

This is a package written by Cognata, intended to assist developers in integrating and automating the usage of CognataStudio.
Included in this package:
* CognataStudio's web-api sdk
* Scenarios editing module
